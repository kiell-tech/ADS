<?php
// logout.php — Destroys session and redirects to login
session_start();
session_destroy();
header('Location: /bulsu_voting/index.php?success=You+have+been+logged+out.');
exit;
