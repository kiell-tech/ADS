-- ============================================================
-- STORED PROCEDURES — bulsu_voting
-- ============================================================

USE bulsu_voting;

DELIMITER $$

-- ============================================================
-- PROCEDURE 1: Cast a vote (with full validation)
-- ============================================================
DROP PROCEDURE IF EXISTS sp_cast_vote$$
CREATE PROCEDURE sp_cast_vote(
    IN  p_election_id  INT,
    IN  p_position_id  INT,
    IN  p_student_id   VARCHAR(20),
    IN  p_candidate_id INT,
    OUT p_result       VARCHAR(100)
)
BEGIN
    DECLARE v_status      VARCHAR(20);
    DECLARE v_now         DATETIME;
    DECLARE v_start       DATETIME;
    DECLARE v_end         DATETIME;
    DECLARE v_already     INT DEFAULT 0;
    DECLARE v_verified    TINYINT DEFAULT 0;

    SET v_now = NOW();

    -- Check student is verified
    SELECT is_verified INTO v_verified
    FROM students WHERE student_id = p_student_id;

    IF v_verified = 0 THEN
        SET p_result = 'ERROR: Your account has not been verified by the admin yet.';
    ELSE
        -- Check election status and period
        SELECT status, start_date, end_date
        INTO v_status, v_start, v_end
        FROM elections WHERE election_id = p_election_id;

        IF v_status != 'active' THEN
            SET p_result = 'ERROR: Election is not currently active.';
        ELSEIF v_now < v_start THEN
            SET p_result = 'ERROR: Voting period has not started yet.';
        ELSEIF v_now > v_end THEN
            SET p_result = 'ERROR: Voting period has already ended.';
        ELSE
            -- Check for duplicate vote
            SELECT COUNT(*) INTO v_already
            FROM votes
            WHERE election_id = p_election_id
              AND position_id  = p_position_id
              AND student_id   = p_student_id;

            IF v_already > 0 THEN
                SET p_result = 'ERROR: You have already voted for this position.';
            ELSE
                -- Cast the vote inside a transaction
                START TRANSACTION;
                INSERT INTO votes (election_id, position_id, student_id, candidate_id)
                VALUES (p_election_id, p_position_id, p_student_id, p_candidate_id);
                COMMIT;
                SET p_result = 'SUCCESS: Vote cast successfully.';
            END IF;
        END IF;
    END IF;
END$$

-- ============================================================
-- PROCEDURE 2: Get election results
-- ============================================================
DROP PROCEDURE IF EXISTS sp_get_results$$
CREATE PROCEDURE sp_get_results(IN p_election_id INT)
BEGIN
    SELECT
        p.position_name,
        p.display_order,
        c.candidate_id,
        c.full_name       AS candidate_name,
        COUNT(v.vote_id)  AS total_votes
    FROM positions p
    JOIN candidates c ON c.position_id = p.position_id
        AND c.election_id = p_election_id
    LEFT JOIN votes v ON v.candidate_id = c.candidate_id
        AND v.election_id = p_election_id
    WHERE p.election_id = p_election_id
    GROUP BY p.position_id, c.candidate_id
    ORDER BY p.display_order ASC, total_votes DESC;
END$$

-- ============================================================
-- PROCEDURE 3: Get voter turnout
-- ============================================================
DROP PROCEDURE IF EXISTS sp_get_turnout$$
CREATE PROCEDURE sp_get_turnout(IN p_election_id INT)
BEGIN
    SELECT
        (SELECT COUNT(DISTINCT student_id) FROM votes WHERE election_id = p_election_id) AS total_voted,
        (SELECT COUNT(*) FROM students WHERE is_verified = 1)                            AS total_eligible,
        ROUND(
            (SELECT COUNT(DISTINCT student_id) FROM votes WHERE election_id = p_election_id)
            /
            NULLIF((SELECT COUNT(*) FROM students WHERE is_verified = 1), 0)
            * 100, 2
        ) AS turnout_percentage;
END$$

DELIMITER ;
