-- ============================================================
-- BULSU CICT ONLINE VOTING SYSTEM
-- Database: bulsu_voting
-- Author: MBEZ Solutions
-- ============================================================

CREATE DATABASE IF NOT EXISTS bulsu_voting
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE bulsu_voting;

-- ============================================================
-- TABLE 1: admins
-- Stores admin / election officer accounts
-- ============================================================
CREATE TABLE IF NOT EXISTS admins (
    admin_id    INT AUTO_INCREMENT PRIMARY KEY,
    full_name   VARCHAR(100)  NOT NULL,
    username    VARCHAR(50)   NOT NULL UNIQUE,
    password    VARCHAR(255)  NOT NULL,
    created_at  TIMESTAMP     DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================================
-- TABLE 2: students
-- Stores registered CICT student voters
-- ============================================================
CREATE TABLE IF NOT EXISTS students (
    student_id    VARCHAR(20)  PRIMARY KEY,
    full_name     VARCHAR(100) NOT NULL,
    email         VARCHAR(100) NOT NULL UNIQUE,
    password      VARCHAR(255) NOT NULL,
    year_admitted YEAR         NOT NULL,
    is_verified   TINYINT(1)   DEFAULT 0,
    created_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================================
-- TABLE 3: elections
-- Stores election events
-- ============================================================
CREATE TABLE IF NOT EXISTS elections (
    election_id   INT AUTO_INCREMENT PRIMARY KEY,
    election_name VARCHAR(150) NOT NULL,
    start_date    DATETIME     NOT NULL,
    end_date      DATETIME     NOT NULL,
    status        ENUM('pending','active','closed') DEFAULT 'pending',
    created_by    INT,
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_election_admin FOREIGN KEY (created_by)
        REFERENCES admins(admin_id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ============================================================
-- TABLE 4: positions
-- Fixed positions per election
-- ============================================================
CREATE TABLE IF NOT EXISTS positions (
    position_id   INT AUTO_INCREMENT PRIMARY KEY,
    election_id   INT          NOT NULL,
    position_name VARCHAR(100) NOT NULL,
    max_candidates INT         DEFAULT 4,
    display_order INT          NOT NULL DEFAULT 1,
    CONSTRAINT fk_position_election FOREIGN KEY (election_id)
        REFERENCES elections(election_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- TABLE 5: candidates
-- Candidates per position per election
-- ============================================================
CREATE TABLE IF NOT EXISTS candidates (
    candidate_id INT AUTO_INCREMENT PRIMARY KEY,
    election_id  INT          NOT NULL,
    position_id  INT          NOT NULL,
    student_id   VARCHAR(20)  NOT NULL,
    full_name    VARCHAR(100) NOT NULL,
    platform     TEXT,
    photo        VARCHAR(255) DEFAULT NULL,
    created_at   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_candidate_election FOREIGN KEY (election_id)
        REFERENCES elections(election_id) ON DELETE CASCADE,
    CONSTRAINT fk_candidate_position FOREIGN KEY (position_id)
        REFERENCES positions(position_id) ON DELETE CASCADE,
    CONSTRAINT fk_candidate_student FOREIGN KEY (student_id)
        REFERENCES students(student_id) ON DELETE CASCADE,
    CONSTRAINT uq_candidate_position UNIQUE (election_id, position_id, student_id)
) ENGINE=InnoDB;

-- ============================================================
-- TABLE 6: votes
-- Cast votes — DELETE is blocked by trigger
-- ============================================================
CREATE TABLE IF NOT EXISTS votes (
    vote_id      INT AUTO_INCREMENT PRIMARY KEY,
    election_id  INT         NOT NULL,
    position_id  INT         NOT NULL,
    student_id   VARCHAR(20) NOT NULL,
    candidate_id INT         NOT NULL,
    voted_at     TIMESTAMP   DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_vote_election  FOREIGN KEY (election_id)
        REFERENCES elections(election_id) ON DELETE CASCADE,
    CONSTRAINT fk_vote_position  FOREIGN KEY (position_id)
        REFERENCES positions(position_id) ON DELETE CASCADE,
    CONSTRAINT fk_vote_student   FOREIGN KEY (student_id)
        REFERENCES students(student_id) ON DELETE CASCADE,
    CONSTRAINT fk_vote_candidate FOREIGN KEY (candidate_id)
        REFERENCES candidates(candidate_id) ON DELETE CASCADE,
    CONSTRAINT uq_one_vote UNIQUE (election_id, position_id, student_id)
) ENGINE=InnoDB;

-- ============================================================
-- TABLE 7: vote_logs
-- Audit trail — auto-populated by trigger
-- ============================================================
CREATE TABLE IF NOT EXISTS vote_logs (
    log_id       INT AUTO_INCREMENT PRIMARY KEY,
    student_id   VARCHAR(20) NOT NULL,
    election_id  INT         NOT NULL,
    position_id  INT         NOT NULL,
    candidate_id INT         NOT NULL,
    action       VARCHAR(50) NOT NULL DEFAULT 'VOTE_CAST',
    logged_at    TIMESTAMP   DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================================
-- INDEXES for performance
-- ============================================================
CREATE INDEX idx_votes_student    ON votes(student_id);
CREATE INDEX idx_votes_election   ON votes(election_id);
CREATE INDEX idx_votes_position   ON votes(position_id);
CREATE INDEX idx_candidates_pos   ON candidates(election_id, position_id);
CREATE INDEX idx_students_id      ON students(student_id);
CREATE INDEX idx_vote_logs_student ON vote_logs(student_id, election_id);

-- ============================================================
-- DEFAULT ADMIN ACCOUNT
-- Username: admin | Password: Admin@2025
-- ============================================================
INSERT INTO admins (full_name, username, password) VALUES
('CICT Election Officer', 'admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');
-- Note: Password above is 'password' hashed. Will be replaced by setup script.
