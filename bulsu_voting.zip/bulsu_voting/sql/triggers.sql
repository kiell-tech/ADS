-- ============================================================
-- TRIGGERS — bulsu_voting
-- ============================================================

USE bulsu_voting;

DELIMITER $$

-- ============================================================
-- TRIGGER 1: After vote insert → log to vote_logs
-- ============================================================
DROP TRIGGER IF EXISTS trg_after_vote_insert$$
CREATE TRIGGER trg_after_vote_insert
AFTER INSERT ON votes
FOR EACH ROW
BEGIN
    INSERT INTO vote_logs (student_id, election_id, position_id, candidate_id, action)
    VALUES (NEW.student_id, NEW.election_id, NEW.position_id, NEW.candidate_id, 'VOTE_CAST');
END$$

-- ============================================================
-- TRIGGER 2: Prevent DELETE on votes table
-- ============================================================
DROP TRIGGER IF EXISTS trg_prevent_vote_delete$$
CREATE TRIGGER trg_prevent_vote_delete
BEFORE DELETE ON votes
FOR EACH ROW
BEGIN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Deletion of votes is not allowed. Votes are permanent once cast.';
END$$

-- ============================================================
-- TRIGGER 3: Validate candidate limit before insert
-- ============================================================
DROP TRIGGER IF EXISTS trg_check_candidate_limit$$
CREATE TRIGGER trg_check_candidate_limit
BEFORE INSERT ON candidates
FOR EACH ROW
BEGIN
    DECLARE candidate_count INT;
    DECLARE max_allowed INT;

    SELECT COUNT(*) INTO candidate_count
    FROM candidates
    WHERE position_id = NEW.position_id AND election_id = NEW.election_id;

    SELECT max_candidates INTO max_allowed
    FROM positions
    WHERE position_id = NEW.position_id;

    IF candidate_count >= max_allowed THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Maximum number of candidates for this position has been reached.';
    END IF;
END$$

DELIMITER ;
