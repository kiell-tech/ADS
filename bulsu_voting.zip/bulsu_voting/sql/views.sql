-- ============================================================
-- VIEWS — bulsu_voting
-- ============================================================

USE bulsu_voting;

-- ============================================================
-- VIEW 1: Live vote results per candidate per position
-- ============================================================
DROP VIEW IF EXISTS vw_results;
CREATE VIEW vw_results AS
SELECT
    e.election_id,
    e.election_name,
    p.position_id,
    p.position_name,
    p.display_order,
    c.candidate_id,
    c.full_name         AS candidate_name,
    COUNT(v.vote_id)    AS total_votes
FROM elections e
JOIN positions  p ON p.election_id  = e.election_id
JOIN candidates c ON c.position_id  = p.position_id AND c.election_id = e.election_id
LEFT JOIN votes v ON v.candidate_id = c.candidate_id AND v.election_id = e.election_id
GROUP BY e.election_id, p.position_id, c.candidate_id
ORDER BY e.election_id, p.display_order, total_votes DESC;

-- ============================================================
-- VIEW 2: Voter turnout per election
-- ============================================================
DROP VIEW IF EXISTS vw_turnout;
CREATE VIEW vw_turnout AS
SELECT
    e.election_id,
    e.election_name,
    e.status,
    (SELECT COUNT(DISTINCT student_id) FROM votes v WHERE v.election_id = e.election_id) AS voters_participated,
    (SELECT COUNT(*) FROM students WHERE is_verified = 1) AS total_eligible,
    ROUND(
        (SELECT COUNT(DISTINCT student_id) FROM votes v WHERE v.election_id = e.election_id)
        / NULLIF((SELECT COUNT(*) FROM students WHERE is_verified = 1), 0) * 100, 2
    ) AS turnout_pct
FROM elections e;

-- ============================================================
-- VIEW 3: Winners per position per election
-- ============================================================
DROP VIEW IF EXISTS vw_winners;
CREATE VIEW vw_winners AS
SELECT
    r.election_id,
    r.election_name,
    r.position_id,
    r.position_name,
    r.candidate_name   AS winner,
    r.total_votes      AS winning_votes
FROM vw_results r
WHERE r.total_votes = (
    SELECT MAX(r2.total_votes)
    FROM vw_results r2
    WHERE r2.position_id = r.position_id AND r2.election_id = r.election_id
);
