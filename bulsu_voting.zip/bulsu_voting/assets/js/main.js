// ============================================================
// main.js — BulSU CICT Online Voting System
// ============================================================

document.addEventListener('DOMContentLoaded', function () {

    // ── Auto-dismiss alerts after 4 seconds ──
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(function (alert) {
        setTimeout(function () {
            alert.style.transition = 'opacity .5s ease';
            alert.style.opacity = '0';
            setTimeout(function () { alert.remove(); }, 500);
        }, 4000);
    });

    // ── Modal open/close ──
    document.querySelectorAll('[data-modal-open]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            const id = btn.getAttribute('data-modal-open');
            const modal = document.getElementById(id);
            if (modal) modal.classList.add('open');
        });
    });
    document.querySelectorAll('.modal-close, [data-modal-close]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            btn.closest('.modal-overlay').classList.remove('open');
        });
    });
    document.querySelectorAll('.modal-overlay').forEach(function (overlay) {
        overlay.addEventListener('click', function (e) {
            if (e.target === overlay) overlay.classList.remove('open');
        });
    });

    // ── Candidate card selection (voting page) ──
    document.querySelectorAll('.candidate-card').forEach(function (card) {
        card.addEventListener('click', function () {
            const positionGroup = card.closest('.position-section');
            if (!positionGroup) return;
            positionGroup.querySelectorAll('.candidate-card').forEach(function (c) {
                c.classList.remove('selected');
            });
            card.classList.add('selected');
            const radio = card.querySelector('input[type="radio"]');
            if (radio) radio.checked = true;
        });
    });

    // ── Student ID year extraction (registration) ──
    const studentIdInput = document.getElementById('student_id');
    const yearInput = document.getElementById('year_admitted');
    if (studentIdInput && yearInput) {
        studentIdInput.addEventListener('input', function () {
            const val = studentIdInput.value.trim();
            if (val.length >= 4) {
                const year = val.substring(0, 4);
                if (/^\d{4}$/.test(year)) yearInput.value = year;
            }
        });
    }

    // ── Confirm delete dialogs ──
    document.querySelectorAll('.confirm-delete').forEach(function (btn) {
        btn.addEventListener('click', function (e) {
            const msg = btn.getAttribute('data-confirm') || 'Are you sure you want to delete this record?';
            if (!confirm(msg)) e.preventDefault();
        });
    });

    // ── Vote submit confirmation ──
    const voteForm = document.getElementById('vote-form');
    if (voteForm) {
        voteForm.addEventListener('submit', function (e) {
            const positions = voteForm.querySelectorAll('.position-section');
            let allVoted = true;
            positions.forEach(function (pos) {
                const radios = pos.querySelectorAll('input[type="radio"]');
                const checked = Array.from(radios).some(r => r.checked);
                if (!checked) allVoted = false;
            });
            if (!allVoted) {
                e.preventDefault();
                alert('Please select a candidate for every position before submitting.');
                return;
            }
            if (!confirm('Are you sure you want to submit your votes? This cannot be undone.')) {
                e.preventDefault();
            }
        });
    }

    // ── Result bar animation ──
    document.querySelectorAll('.result-bar').forEach(function (bar) {
        const target = bar.getAttribute('data-width') || '0';
        bar.style.width = '0%';
        setTimeout(function () { bar.style.width = target + '%'; }, 200);
    });

    // ── Sidebar active link highlight ──
    const currentPath = window.location.pathname;
    document.querySelectorAll('.sidebar-nav a').forEach(function (link) {
        if (currentPath.includes(link.getAttribute('href'))) {
            link.classList.add('active');
        }
    });

    // ── Edit modal population (admin CRUD) ──
    document.querySelectorAll('[data-edit]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            const data = JSON.parse(btn.getAttribute('data-edit'));
            const modalId = btn.getAttribute('data-modal-open');
            const modal = document.getElementById(modalId);
            if (!modal) return;
            Object.keys(data).forEach(function (key) {
                const field = modal.querySelector('[name="' + key + '"]');
                if (field) field.value = data[key];
            });
            modal.classList.add('open');
        });
    });

    // ── Election status auto-update hint ──
    const statusBadges = document.querySelectorAll('[data-election-status]');
    statusBadges.forEach(function (badge) {
        const status = badge.getAttribute('data-election-status');
        badge.className = 'badge badge-' + status;
    });
});
