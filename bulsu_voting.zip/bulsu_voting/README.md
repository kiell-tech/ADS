# BulSU CICT Online Voting System
## MBEZ Solutions — Setup & Run Guide

---

## ✅ REQUIREMENTS
- XAMPP (Apache + MySQL) — PHP 8.2+
- Browser (Chrome, Firefox, Edge)

---

## 🚀 INSTALLATION STEPS

### Step 1 — Copy Project Folder
Copy the `bulsu_voting` folder into:
```
C:\xampp\htdocs\bulsu_voting\
```

### Step 2 — Start XAMPP
- Open XAMPP Control Panel
- Start **Apache** and **MySQL**

### Step 3 — Run Setup Script
Open your browser and go to:
```
http://localhost/bulsu_voting/setup.php
```
This will automatically:
- Create the `bulsu_voting` database
- Create all 7 tables
- Install triggers, stored procedures, and views
- Create the default admin account

### Step 4 — Delete Setup File
After setup completes, **delete** `setup.php` from the project folder for security.

### Step 5 — Open the System
```
http://localhost/bulsu_voting/
```

---

## 🔐 DEFAULT LOGIN CREDENTIALS

### Admin
| Field    | Value       |
|----------|-------------|
| Role     | Admin       |
| Username | admin       |
| Password | Admin@2025  |

### Student
Register a new account at:
```
http://localhost/bulsu_voting/register.php
```
Then verify it in the Admin panel → Voters.

---

## 📁 PROJECT STRUCTURE
```
bulsu_voting/
├── index.php              ← Login page
├── register.php           ← Student registration
├── logout.php
├── setup.php              ← ⚠ DELETE AFTER SETUP
├── config/
│   └── db.php             ← Database connection
├── admin/
│   ├── dashboard.php
│   ├── elections.php
│   ├── positions.php
│   ├── candidates.php
│   ├── voters.php
│   ├── results.php
│   └── backup.php
├── student/
│   ├── dashboard.php
│   ├── vote.php
│   └── confirmation.php
├── includes/
│   ├── auth_admin.php
│   ├── auth_student.php
│   ├── header.php
│   └── footer.php
├── assets/
│   ├── css/style.css
│   ├── js/main.js
│   └── images/
│       └── logo_placeholder.png  ← Replace with real BulSU logo
└── sql/
    ├── bulsu_voting.sql    ← Tables + indexes
    ├── triggers.sql        ← 3 triggers
    ├── procedures.sql      ← 3 stored procedures
    └── views.sql           ← 3 views
```

---

## 🖼 ADDING THE REAL BulSU LOGO
1. Save the official BulSU logo as `bulsu_logo.png`
2. Place it in: `assets/images/`
3. In all PHP files, change:
   ```
   logo_placeholder.png → bulsu_logo.png
   ```

---

## 🗳 HOW TO RUN AN ELECTION

1. **Login as Admin** (`admin` / `Admin@2025`)
2. Go to **Elections** → Create New Election (set dates, status = Active)
   - 6 CICT positions are auto-created
3. Go to **Voters** → Verify student accounts
4. Go to **Candidates** → Add candidates per position
5. Students **login → Vote Now** → cast votes
6. Admin views **Results** for live vote count and winners
7. Use **Backup** to download SQL dump

---

## 🛡 ADVANCED DATABASE FEATURES
| Feature           | Implementation                            |
|-------------------|-------------------------------------------|
| Stored Procedures | sp_cast_vote, sp_get_results, sp_get_turnout |
| Triggers          | Vote logging, delete prevention, candidate limit |
| Views             | vw_results, vw_turnout, vw_winners        |
| Indexing          | votes, candidates, students tables        |
| Transactions      | Atomic vote submission                   |
| User Roles        | Admin vs Student session roles            |
| Normalization     | 3NF — 7 related tables                   |
| Backup & Restore  | Admin panel SQL dump download             |

---

## 👥 TEAM
**MBEZ Solutions**
- Esma, Sam Ezekiel O.
- Espinola, Zynel Miguel R.
- Lazaro, Blaise Wilhelm U.
- Sta Ana, Jerie Miko DS

**Subject:** Advanced Database Systems
**School:** Bulacan State University — CICT
