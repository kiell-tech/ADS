<?php
// ============================================================
// index.php — Login Page (Student & Admin)
// ============================================================
session_start();

define('BASE_URL', '/bulsu_voting/');

// Redirect if already logged in
if (isset($_SESSION['admin_id']))   { header('Location: admin/dashboard.php');   exit; }
if (isset($_SESSION['student_id'])) { header('Location: student/dashboard.php'); exit; }

require_once __DIR__ . '/config/db.php';

$error   = '';
$success = '';

if (isset($_GET['error']))   $error   = htmlspecialchars($_GET['error']);
if (isset($_GET['success'])) $success = htmlspecialchars($_GET['success']);

// ── Process login ──
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'login') {
    $role     = $_POST['role']     ?? '';
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (empty($username) || empty($password)) {
        $error = 'Please fill in all fields.';
    } else {
        $db = getDB();

        if ($role === 'admin') {
            $stmt = $db->prepare("SELECT * FROM admins WHERE username = ? LIMIT 1");
            $stmt->execute([$username]);
            $admin = $stmt->fetch();

            if ($admin && password_verify($password, $admin['password'])) {
                $_SESSION['admin_id']   = $admin['admin_id'];
                $_SESSION['admin_name'] = $admin['full_name'];
                header('Location: admin/dashboard.php');
                exit;
            } else {
                $error = 'Invalid admin credentials.';
            }
        } elseif ($role === 'student') {
            $stmt = $db->prepare("SELECT * FROM students WHERE student_id = ? LIMIT 1");
            $stmt->execute([$username]);
            $student = $stmt->fetch();

            if ($student && password_verify($password, $student['password'])) {
                if ($student['is_verified'] == 0) {
                    $error = 'Your account is pending admin verification. Please wait.';
                } else {
                    $_SESSION['student_id']   = $student['student_id'];
                    $_SESSION['student_name'] = $student['full_name'];
                    header('Location: student/dashboard.php');
                    exit;
                }
            } else {
                $error = 'Invalid Student ID or password.';
            }
        } else {
            $error = 'Please select a login role.';
        }
    }
}
define('PAGE_TITLE', 'Login');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | BulSU CICT Online Voting System</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        .tab-switcher { display: flex; margin-bottom: 1.5rem; border-radius: var(--radius); overflow: hidden; border: 1.5px solid var(--gray-200); }
        .tab-btn { flex: 1; padding: .6rem; border: none; background: var(--gray-100); font-family: 'DM Sans', sans-serif; font-size: .85rem; font-weight: 600; cursor: pointer; transition: all var(--transition); color: var(--gray-400); }
        .tab-btn.active { background: var(--red-dark); color: var(--white); }
        .role-field { display: none; }
    </style>
</head>
<body>
<div class="hero-page">
    <div class="decor-ring"></div>
    <div class="decor-ring"></div>

    <div class="auth-card">
        <div class="auth-logo">
            <!-- REPLACE src with real BulSU logo path: assets/images/bulsu_logo.png -->
            <img src="<?= BASE_URL ?>assets/images/bulsu_logo.png"
                 alt="BulSU Logo"
                 onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
            <div style="display:none; width:72px;height:72px;border-radius:50%;background:var(--red-dark);align-items:center;justify-content:center;margin:0 auto .75rem;border:3px solid var(--gold);">
                <i class="fas fa-university" style="color:var(--gold);font-size:1.8rem;"></i>
            </div>
            <h2>BulSU CICT</h2>
            <p>Online Voting System</p>
        </div>

        <div class="auth-divider"></div>

        <?php if ($error):   ?><div class="alert alert-error"><i class="fas fa-circle-exclamation"></i><?= $error ?></div><?php endif; ?>
        <?php if ($success): ?><div class="alert alert-success"><i class="fas fa-circle-check"></i><?= $success ?></div><?php endif; ?>

        <!-- Role tabs -->
        <div class="tab-switcher">
            <button class="tab-btn active" onclick="switchRole('student', this)">
                <i class="fas fa-user-graduate"></i> Student
            </button>
            <button class="tab-btn" onclick="switchRole('admin', this)">
                <i class="fas fa-shield-halved"></i> Admin
            </button>
        </div>

        <form method="POST" action="">
            <input type="hidden" name="action" value="login">
            <input type="hidden" name="role" id="role_input" value="student">

            <div class="form-group">
                <label id="username_label"><i class="fas fa-id-card"></i> Student ID</label>
                <div class="input-icon-wrap">
                    <i class="fas fa-user input-icon"></i>
                    <input type="text" name="username" class="form-control"
                           id="username_field"
                           placeholder="Enter your Student ID (e.g. 2024100815)"
                           required autocomplete="username">
                </div>
            </div>

            <div class="form-group">
                <label><i class="fas fa-lock"></i> Password</label>
                <div class="input-icon-wrap">
                    <i class="fas fa-lock input-icon"></i>
                    <input type="password" name="password" class="form-control"
                           placeholder="Enter your password"
                           required autocomplete="current-password">
                </div>
            </div>

            <button type="submit" class="btn btn-primary btn-full btn-lg mt-2">
                <i class="fas fa-right-to-bracket"></i> Sign In
            </button>
        </form>

        <p class="text-center mt-2" style="font-size:.85rem; color:var(--gray-400);">
            Don't have an account?
            <a href="register.php" style="color:var(--red); font-weight:600;">Register here</a>
        </p>

        <p class="text-center mt-1" style="font-size:.75rem; color:var(--gray-400);">
            Exclusively for CICT Students of Bulacan State University
        </p>
    </div>
</div>

<script src="<?= BASE_URL ?>assets/js/main.js"></script>
<script>
function switchRole(role, btn) {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('role_input').value = role;
    const label = document.getElementById('username_label');
    const field = document.getElementById('username_field');
    if (role === 'admin') {
        label.innerHTML = '<i class="fas fa-user-shield"></i> Admin Username';
        field.placeholder = 'Enter admin username';
    } else {
        label.innerHTML = '<i class="fas fa-id-card"></i> Student ID';
        field.placeholder = 'Enter your Student ID (e.g. 2024100815)';
    }
}
</script>
</body>
</html>
