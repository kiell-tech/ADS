<?php
// includes/auth_admin.php — Protects admin pages
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['admin_id'])) {
    header('Location: ' . BASE_URL . 'index.php?error=Please+login+as+admin.');
    exit;
}
