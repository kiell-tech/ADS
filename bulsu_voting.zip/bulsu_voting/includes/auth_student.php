<?php
// includes/auth_student.php — Protects student pages
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['student_id'])) {
    header('Location: ' . BASE_URL . 'index.php?error=Please+login+to+continue.');
    exit;
}
