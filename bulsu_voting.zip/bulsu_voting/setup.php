<?php
// ============================================================
// setup.php — One-time Database Setup Script
// Run this ONCE at: http://localhost/bulsu_voting/setup.php
// Delete this file after setup is complete!
// ============================================================

$host = 'localhost';
$user = 'root';
$pass = '';

try {
    // Connect without selecting a DB first
    $pdo = new PDO("mysql:host=$host;charset=utf8mb4", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    ]);

    // Read and execute main SQL file
    $sql_files = [
        __DIR__ . '/sql/bulsu_voting.sql',
        __DIR__ . '/sql/triggers.sql',
        __DIR__ . '/sql/procedures.sql',
        __DIR__ . '/sql/views.sql',
    ];

    $pdo->exec("CREATE DATABASE IF NOT EXISTS bulsu_voting CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;");
    $pdo->exec("USE bulsu_voting;");

    // Run each SQL file
    foreach ($sql_files as $file) {
        if (!file_exists($file)) { echo "<p style='color:orange;'>⚠ File not found: $file</p>"; continue; }
        $sql = file_get_contents($file);
        // Split on semicolons but skip empty
        $statements = array_filter(array_map('trim', explode(';', $sql)));
        foreach ($statements as $stmt) {
            if (!empty($stmt) && strtoupper(substr(ltrim($stmt),0,9)) !== 'DELIMITER') {
                try { $pdo->exec($stmt . ';'); } catch (PDOException $e) { /* Skip non-fatal */ }
            }
        }
        echo "<p style='color:green;'>✅ Executed: " . basename($file) . "</p>";
    }

    // Fix admin password with correct PHP hash
    $pdo->exec("USE bulsu_voting;");
    $adminHash = password_hash('Admin@2025', PASSWORD_BCRYPT);
    $stmt = $pdo->prepare("UPDATE admins SET password=? WHERE username='admin'");
    $stmt->execute([$adminHash]);

    echo "
    <html>
    <head><title>BulSU Setup</title>
    <style>
        body{font-family:sans-serif;max-width:600px;margin:40px auto;padding:20px;background:#faf8f5;}
        .box{background:white;border-radius:12px;padding:2rem;box-shadow:0 4px 20px rgba(0,0,0,.1);}
        h2{color:#6B0F0F;} .success{color:#15803D;font-size:1.1rem;}
        table{width:100%;border-collapse:collapse;margin-top:1rem;}
        td,th{padding:.6rem 1rem;border:1px solid #eee;font-size:.9rem;}
        th{background:#f5f4f2;} .warn{color:#b45309;background:#fffbeb;padding:.75rem;border-radius:8px;margin-top:1rem;font-size:.85rem;}
        a.btn{display:inline-block;margin-top:1rem;padding:.65rem 1.5rem;background:#9B1C1C;color:white;border-radius:8px;text-decoration:none;}
    </style>
    </head>
    <body><div class='box'>
    <h2>🎓 BulSU CICT Voting System — Setup Complete!</h2>
    <p class='success'>✅ Database <strong>bulsu_voting</strong> has been created and configured successfully.</p>

    <table>
        <tr><th>Item</th><th>Value</th></tr>
        <tr><td>Database</td><td>bulsu_voting</td></tr>
        <tr><td>Tables Created</td><td>admins, students, elections, positions, candidates, votes, vote_logs</td></tr>
        <tr><td>Triggers</td><td>3 triggers installed</td></tr>
        <tr><td>Stored Procedures</td><td>sp_cast_vote, sp_get_results, sp_get_turnout</td></tr>
        <tr><td>Views</td><td>vw_results, vw_turnout, vw_winners</td></tr>
        <tr><td>Admin Username</td><td><strong>admin</strong></td></tr>
        <tr><td>Admin Password</td><td><strong>Admin@2025</strong></td></tr>
    </table>

    <div class='warn'>⚠️ <strong>Important:</strong> Delete or rename this setup.php file after setup is complete for security.</div>
    <a href='/bulsu_voting/index.php' class='btn'>→ Go to Login Page</a>
    </div></body></html>
    ";

} catch (PDOException $e) {
    echo "<h2 style='color:red;'>Setup Failed</h2><pre>" . htmlspecialchars($e->getMessage()) . "</pre>";
    echo "<p>Make sure XAMPP MySQL is running and credentials in this file match your setup.</p>";
}
