<?php
// ============================================================
// register.php — Student Self-Registration
// ============================================================
session_start();
define('BASE_URL', '/bulsu_voting/');

if (isset($_SESSION['student_id'])) { header('Location: student/dashboard.php'); exit; }

require_once __DIR__ . '/config/db.php';

$error   = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_id = trim($_POST['student_id']   ?? '');
    $full_name  = trim($_POST['full_name']    ?? '');
    $email      = trim($_POST['email']        ?? '');
    $password   = trim($_POST['password']     ?? '');
    $confirm_pw = trim($_POST['confirm_pw']   ?? '');

    // ── Validation ──
    if (empty($student_id) || empty($full_name) || empty($email) || empty($password)) {
        $error = 'All fields are required.';
    } elseif (!preg_match('/^\d{10}$/', $student_id)) {
        $error = 'Student ID must be exactly 10 digits (e.g. 2024100815).';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif (strlen($password) < 8) {
        $error = 'Password must be at least 8 characters.';
    } elseif ($password !== $confirm_pw) {
        $error = 'Passwords do not match.';
    } else {
        $year_admitted = substr($student_id, 0, 4);
        $hashed_pw     = password_hash($password, PASSWORD_BCRYPT);

        try {
            $db   = getDB();
            $stmt = $db->prepare(
                "INSERT INTO students (student_id, full_name, email, password, year_admitted)
                 VALUES (?, ?, ?, ?, ?)"
            );
            $stmt->execute([$student_id, $full_name, $email, $hashed_pw, $year_admitted]);
            header('Location: index.php?success=Registration+successful!+Please+wait+for+admin+verification.');
            exit;
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                $error = 'Student ID or Email already registered.';
            } else {
                $error = 'Registration failed. Please try again.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | BulSU CICT Online Voting System</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        .auth-card { max-width: 500px; }
    </style>
</head>
<body>
<div class="hero-page">
    <div class="decor-ring"></div>
    <div class="decor-ring"></div>

    <div class="auth-card">
        <div class="auth-logo">
            <img src="<?= BASE_URL ?>assets/images/logo_placeholder.png"
                 alt="BulSU Logo"
                 onerror="this.style.display='none'">
            <h2>Create Account</h2>
            <p>CICT Student Registration</p>
        </div>

        <div class="auth-divider"></div>

        <?php if ($error):   ?><div class="alert alert-error"><i class="fas fa-circle-exclamation"></i><?= htmlspecialchars($error) ?></div><?php endif; ?>

        <form method="POST" action="">
            <div class="form-group">
                <label>Student ID</label>
                <div class="input-icon-wrap">
                    <i class="fas fa-id-card input-icon"></i>
                    <input type="text" name="student_id" id="student_id" class="form-control"
                           placeholder="e.g. 2024100815"
                           value="<?= htmlspecialchars($_POST['student_id'] ?? '') ?>"
                           maxlength="10" required>
                </div>
                <small style="color:var(--gray-400); font-size:.75rem;">10-digit Student ID (first 4 digits = year admitted)</small>
            </div>

            <input type="hidden" name="year_admitted" id="year_admitted">

            <div class="form-group">
                <label>Full Name</label>
                <div class="input-icon-wrap">
                    <i class="fas fa-user input-icon"></i>
                    <input type="text" name="full_name" class="form-control"
                           placeholder="Last Name, First Name M.I."
                           value="<?= htmlspecialchars($_POST['full_name'] ?? '') ?>"
                           required>
                </div>
            </div>

            <div class="form-group">
                <label>Email Address</label>
                <div class="input-icon-wrap">
                    <i class="fas fa-envelope input-icon"></i>
                    <input type="email" name="email" class="form-control"
                           placeholder="your@email.com"
                           value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                           required>
                </div>
            </div>

            <div class="form-group">
                <label>Password</label>
                <div class="input-icon-wrap">
                    <i class="fas fa-lock input-icon"></i>
                    <input type="password" name="password" class="form-control"
                           placeholder="Minimum 8 characters" required>
                </div>
            </div>

            <div class="form-group">
                <label>Confirm Password</label>
                <div class="input-icon-wrap">
                    <i class="fas fa-lock input-icon"></i>
                    <input type="password" name="confirm_pw" class="form-control"
                           placeholder="Re-enter your password" required>
                </div>
            </div>

            <div class="alert alert-info mt-1">
                <i class="fas fa-circle-info"></i>
                <span>After registration, wait for admin verification before you can login.</span>
            </div>

            <button type="submit" class="btn btn-primary btn-full btn-lg mt-2">
                <i class="fas fa-user-plus"></i> Register
            </button>
        </form>

        <p class="text-center mt-2" style="font-size:.85rem; color:var(--gray-400);">
            Already have an account?
            <a href="index.php" style="color:var(--red); font-weight:600;">Sign in here</a>
        </p>
    </div>
</div>
<script src="<?= BASE_URL ?>assets/js/main.js"></script>
</body>
</html>
