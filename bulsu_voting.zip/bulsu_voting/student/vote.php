<?php
// ============================================================
// student/vote.php — Cast Vote Page
// ============================================================
session_start();
define('BASE_URL', '/bulsu_voting/');
require_once __DIR__ . '/../includes/auth_student.php';
require_once __DIR__ . '/../config/db.php';
define('PAGE_TITLE', 'Cast Your Vote');

$db         = getDB();
$student_id = $_SESSION['student_id'];
$election_id= (int)($_GET['election_id'] ?? 0);

// Verify student
$sstmt = $db->prepare("SELECT * FROM students WHERE student_id=?");
$sstmt->execute([$student_id]);
$student = $sstmt->fetch();

if (!$student['is_verified']) {
    header('Location: dashboard.php');
    exit;
}

// Get active election
if (!$election_id) {
    $el = $db->query("SELECT * FROM elections WHERE status='active' AND NOW() BETWEEN start_date AND end_date LIMIT 1")->fetch();
    if ($el) $election_id = $el['election_id'];
    else { header('Location: dashboard.php'); exit; }
}

$estmt = $db->prepare("SELECT * FROM elections WHERE election_id=? AND status='active'");
$estmt->execute([$election_id]);
$election = $estmt->fetch();

if (!$election) {
    header('Location: dashboard.php');
    exit;
}

// Check election time window
$now = new DateTime();
$start = new DateTime($election['start_date']);
$end   = new DateTime($election['end_date']);
if ($now < $start || $now > $end) {
    header('Location: dashboard.php');
    exit;
}

$error = $success = '';

// ── Process vote submission ──
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $votes_submitted = $_POST['votes'] ?? [];

    if (empty($votes_submitted)) {
        $error = 'Please select at least one candidate before submitting.';
    } else {
        // Get all positions for this election
        $pos_stmt = $db->prepare("SELECT position_id FROM positions WHERE election_id=?");
        $pos_stmt->execute([$election_id]);
        $all_positions = array_column($pos_stmt->fetchAll(), 'position_id');

        // Check all positions voted
        foreach ($all_positions as $pos_id) {
            if (!isset($votes_submitted[$pos_id])) {
                $error = 'Please select a candidate for every position.';
                break;
            }
        }

        if (empty($error)) {
            $all_success = true;
            $db->beginTransaction();
            try {
                foreach ($votes_submitted as $pos_id => $cand_id) {
                    $pos_id  = (int)$pos_id;
                    $cand_id = (int)$cand_id;

                    // Use stored procedure for each vote
                    $proc = $db->prepare("CALL sp_cast_vote(?, ?, ?, ?, @result)");
                    $proc->execute([$election_id, $pos_id, $student_id, $cand_id]);
                    $proc->closeCursor();

                    $res = $db->query("SELECT @result AS result")->fetch();
                    if (strpos($res['result'], 'ERROR') !== false) {
                        throw new Exception($res['result']);
                    }
                }
                $db->commit();
                header("Location: confirmation.php?election_id=$election_id");
                exit;
            } catch (Exception $e) {
                $db->rollBack();
                $error = str_replace('ERROR: ', '', $e->getMessage());
            }
        }
    }
}

// ── Get positions and candidates ──
$pos_stmt = $db->prepare(
    "SELECT p.*, 
     (SELECT COUNT(*) FROM votes v WHERE v.position_id=p.position_id AND v.student_id=? AND v.election_id=?) AS already_voted
     FROM positions p WHERE p.election_id=? ORDER BY p.display_order"
);
$pos_stmt->execute([$student_id, $election_id, $election_id]);
$positions = $pos_stmt->fetchAll();

$cand_stmt = $db->prepare(
    "SELECT * FROM candidates WHERE election_id=? ORDER BY position_id, full_name"
);
$cand_stmt->execute([$election_id]);
$all_candidates = $cand_stmt->fetchAll();

// Group candidates by position
$by_position = [];
foreach ($all_candidates as $c) {
    $by_position[$c['position_id']][] = $c;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title><?= PAGE_TITLE ?> | BulSU CICT</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<nav class="navbar">
    <div class="navbar-brand">
        <img src="<?= BASE_URL ?>assets/images/logo_placeholder.png" alt="BulSU" onerror="this.style.display='none'">
        <div class="brand-text"><div class="brand-title">BulSU CICT Voting</div><div class="brand-sub">Student Portal</div></div>
    </div>
    <ul class="navbar-nav">
        <li><a href="dashboard.php"><i class="fas fa-gauge"></i> Dashboard</a></li>
        <li><span style="color:var(--gold-light);font-size:.85rem;"><i class="fas fa-circle-user"></i> <?= htmlspecialchars($student['full_name']) ?></span></li>
        <li><a href="<?= BASE_URL ?>logout.php" class="btn-logout"><i class="fas fa-right-from-bracket"></i> Logout</a></li>
    </ul>
</nav>

<div style="max-width:860px;margin:2rem auto;padding:0 1.5rem;">

    <!-- Election Header -->
    <div style="text-align:center;margin-bottom:2rem;">
        <div style="font-size:.75rem;text-transform:uppercase;letter-spacing:.1em;color:var(--gold);font-weight:700;">
            <i class="fas fa-circle" style="font-size:.5rem;animation:pulse 1.5s infinite;vertical-align:middle;"></i> Active Election
        </div>
        <h1 style="font-size:1.8rem;color:var(--red-dark);margin:.4rem 0;"><?= htmlspecialchars($election['election_name']) ?></h1>
        <p style="color:var(--gray-400);font-size:.85rem;">
            <i class="fas fa-clock"></i> Voting ends: <?= date('M d, Y g:i A', strtotime($election['end_date'])) ?>
        </p>
        <div class="gold-line" style="max-width:200px;margin:1rem auto;"></div>
    </div>

    <?php if ($error): ?>
    <div class="alert alert-error"><i class="fas fa-circle-exclamation"></i><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="alert alert-info">
        <i class="fas fa-circle-info"></i>
        <span>Select <strong>one candidate per position</strong>. You must vote for all positions before submitting. Your votes are <strong>final and cannot be changed</strong>.</span>
    </div>

    <form method="POST" id="vote-form">
        <?php foreach ($positions as $pos): ?>
        <?php
            $pos_candidates = $by_position[$pos['position_id']] ?? [];
            $already_voted  = $pos['already_voted'] > 0;
        ?>
        <div class="position-section">
            <div class="position-title">
                <?= htmlspecialchars($pos['position_name']) ?>
                <?php if ($already_voted): ?>
                <span class="badge badge-verified" style="margin-left:.5rem;"><i class="fas fa-check"></i> Voted</span>
                <?php endif; ?>
            </div>

            <?php if ($already_voted): ?>
            <div class="alert alert-success" style="margin-bottom:0;">
                <i class="fas fa-check-circle"></i>
                <span>You have already cast your vote for this position.</span>
            </div>

            <?php elseif (empty($pos_candidates)): ?>
            <div class="alert alert-warning">
                <i class="fas fa-triangle-exclamation"></i>
                <span>No candidates registered for this position yet.</span>
            </div>

            <?php else: ?>
            <div class="candidates-grid">
                <?php foreach ($pos_candidates as $c): ?>
                <label class="candidate-card" style="cursor:pointer;">
                    <i class="fas fa-check-circle check-mark"></i>
                    <input type="radio" name="votes[<?= $pos['position_id'] ?>]"
                           value="<?= $c['candidate_id'] ?>"
                           class="vote-radio" required>
                    <div class="candidate-avatar">
                        <?php if ($c['photo']): ?>
                        <img src="<?= BASE_URL ?>assets/images/<?= htmlspecialchars($c['photo']) ?>" alt="">
                        <?php else: ?>
                        <i class="fas fa-user"></i>
                        <?php endif; ?>
                    </div>
                    <div class="candidate-name"><?= htmlspecialchars($c['full_name']) ?></div>
                    <?php if ($c['platform']): ?>
                    <div class="candidate-platform"><?= htmlspecialchars($c['platform']) ?></div>
                    <?php endif; ?>
                </label>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>

        <?php
        // Check if student has already voted all positions
        $total_pos = count($positions);
        $voted_pos = 0;
        foreach ($positions as $p) { if ($p['already_voted']) $voted_pos++; }
        ?>

        <?php if ($voted_pos < $total_pos): ?>
        <div style="text-align:center;margin-top:2rem;padding-bottom:2rem;">
            <button type="submit" class="btn btn-primary btn-lg" style="min-width:220px;">
                <i class="fas fa-ballot-check"></i> Submit My Votes
            </button>
            <p style="font-size:.78rem;color:var(--gray-400);margin-top:.75rem;">
                <i class="fas fa-lock"></i> Your votes are encrypted and cannot be modified after submission.
            </p>
        </div>
        <?php else: ?>
        <div style="text-align:center;margin-top:2rem;padding-bottom:2rem;">
            <a href="confirmation.php?election_id=<?= $election_id ?>" class="btn btn-gold btn-lg">
                <i class="fas fa-check-double"></i> View My Vote Summary
            </a>
        </div>
        <?php endif; ?>
    </form>
</div>

<style>
@keyframes pulse { 0%,100%{opacity:1;} 50%{opacity:.4;} }
</style>
<script src="<?= BASE_URL ?>assets/js/main.js"></script>
</body>
</html>
