<?php
// ============================================================
// student/dashboard.php — Student Dashboard
// ============================================================
session_start();
define('BASE_URL', '/bulsu_voting/');
require_once __DIR__ . '/../includes/auth_student.php';
require_once __DIR__ . '/../config/db.php';
define('PAGE_TITLE', 'Student Dashboard');

$db         = getDB();
$student_id = $_SESSION['student_id'];

// Student info
$sstmt = $db->prepare("SELECT * FROM students WHERE student_id=?");
$sstmt->execute([$student_id]);
$student = $sstmt->fetch();

// Active election
$election = $db->query(
    "SELECT * FROM elections WHERE status='active' AND NOW() BETWEEN start_date AND end_date ORDER BY election_id DESC LIMIT 1"
)->fetch();

// Pending election (upcoming)
$pending_election = $db->query(
    "SELECT * FROM elections WHERE status='pending' OR (status='active' AND NOW() < start_date) ORDER BY start_date ASC LIMIT 1"
)->fetch();

// Votes already cast by this student
$voted_positions = [];
if ($election) {
    $vstmt = $db->prepare(
        "SELECT v.position_id, p.position_name, c.full_name AS candidate_name
         FROM votes v
         JOIN positions p ON p.position_id = v.position_id
         JOIN candidates c ON c.candidate_id = v.candidate_id
         WHERE v.student_id = ? AND v.election_id = ?"
    );
    $vstmt->execute([$student_id, $election['election_id']]);
    foreach ($vstmt->fetchAll() as $v) {
        $voted_positions[$v['position_id']] = $v;
    }

    // Total positions
    $total_positions = $db->prepare("SELECT COUNT(*) FROM positions WHERE election_id=?");
    $total_positions->execute([$election['election_id']]);
    $total_pos = $total_positions->fetchColumn();
    $voted_count = count($voted_positions);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title><?= PAGE_TITLE ?> | BulSU CICT</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<nav class="navbar">
    <div class="navbar-brand">
        <img src="<?= BASE_URL ?>assets/images/logo_placeholder.png" alt="BulSU" onerror="this.style.display='none'">
        <div class="brand-text"><div class="brand-title">BulSU CICT Voting</div><div class="brand-sub">Student Portal</div></div>
    </div>
    <ul class="navbar-nav">
        <li><a href="dashboard.php"><i class="fas fa-gauge"></i> Dashboard</a></li>
        <?php if ($election): ?>
        <li><a href="vote.php?election_id=<?= $election['election_id'] ?>"><i class="fas fa-ballot-check"></i> Vote Now</a></li>
        <?php endif; ?>
        <li><span style="color:var(--gold-light);font-size:.85rem;"><i class="fas fa-circle-user"></i> <?= htmlspecialchars($student['full_name']) ?></span></li>
        <li><a href="<?= BASE_URL ?>logout.php" class="btn-logout"><i class="fas fa-right-from-bracket"></i> Logout</a></li>
    </ul>
</nav>

<div style="max-width:900px;margin:2rem auto;padding:0 1.5rem;">

    <!-- Welcome Banner -->
    <div style="background:linear-gradient(135deg,var(--red-dark),var(--red));border-radius:var(--radius-lg);padding:2rem;color:white;margin-bottom:1.8rem;position:relative;overflow:hidden;">
        <div style="position:absolute;right:-20px;top:-20px;width:150px;height:150px;background:rgba(255,255,255,.06);border-radius:50%;"></div>
        <div style="position:absolute;right:40px;bottom:-30px;width:100px;height:100px;background:rgba(201,168,76,.1);border-radius:50%;"></div>
        <div style="font-size:.75rem;text-transform:uppercase;letter-spacing:.08em;color:var(--gold-light);margin-bottom:.4rem;">Welcome back</div>
        <h2 style="font-size:1.6rem;margin-bottom:.3rem;"><?= htmlspecialchars($student['full_name']) ?></h2>
        <div style="font-size:.85rem;color:rgba(255,255,255,.75);">
            <i class="fas fa-id-card"></i> <?= $student['student_id'] ?>
            &nbsp;&nbsp;
            <i class="fas fa-graduation-cap"></i> CICT <?= $student['year_admitted'] ?>
        </div>
    </div>

    <?php if (!$student['is_verified']): ?>
    <div class="alert alert-warning">
        <i class="fas fa-hourglass-half"></i>
        <span>Your account is <strong>pending verification</strong> by the admin. You will be able to vote once verified.</span>
    </div>
    <?php endif; ?>

    <!-- Active Election Card -->
    <?php if ($election): ?>
    <div class="card mb-2" style="border-top:4px solid var(--gold);">
        <div class="card-body">
            <div style="display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:1rem;">
                <div>
                    <div style="font-size:.72rem;text-transform:uppercase;letter-spacing:.08em;color:var(--gold);font-weight:700;margin-bottom:.3rem;">
                        <i class="fas fa-circle" style="font-size:.5rem;vertical-align:middle;animation:pulse 1.5s infinite;"></i> Active Election
                    </div>
                    <h3 style="font-size:1.2rem;color:var(--red-dark);margin-bottom:.3rem;"><?= htmlspecialchars($election['election_name']) ?></h3>
                    <p style="font-size:.82rem;color:var(--gray-400);">
                        <i class="fas fa-clock"></i>
                        Ends: <?= date('M d, Y g:i A', strtotime($election['end_date'])) ?>
                    </p>
                </div>
                <div style="text-align:center;">
                    <?php if ($voted_count >= $total_pos): ?>
                        <div style="color:#16A34A;font-weight:700;font-size:.9rem;"><i class="fas fa-check-circle"></i> Voting Complete</div>
                        <a href="confirmation.php?election_id=<?= $election['election_id'] ?>" class="btn btn-outline btn-sm mt-1">View Summary</a>
                    <?php else: ?>
                        <a href="vote.php?election_id=<?= $election['election_id'] ?>" class="btn btn-primary btn-lg">
                            <i class="fas fa-ballot-check"></i> Vote Now
                        </a>
                        <?php if ($voted_count > 0): ?>
                        <div style="font-size:.78rem;color:var(--gray-400);margin-top:.4rem;"><?= $voted_count ?>/<?= $total_pos ?> positions voted</div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>

            <?php if ($voted_count > 0): ?>
            <div class="gold-line"></div>
            <h4 style="font-size:.85rem;font-weight:700;color:var(--gray-600);text-transform:uppercase;letter-spacing:.04em;margin-bottom:.8rem;">Your Votes So Far</h4>
            <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:.75rem;">
                <?php foreach ($voted_positions as $vp): ?>
                <div style="background:var(--gray-100);border-radius:var(--radius);padding:.75rem;border-left:3px solid var(--gold);">
                    <div style="font-size:.72rem;text-transform:uppercase;color:var(--gray-400);margin-bottom:.2rem;"><?= htmlspecialchars($vp['position_name']) ?></div>
                    <div style="font-weight:600;font-size:.88rem;color:var(--gray-800);"><?= htmlspecialchars($vp['candidate_name']) ?></div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <?php elseif ($pending_election): ?>
    <div class="card mb-2" style="border-left:4px solid var(--gold);">
        <div class="card-body" style="display:flex;align-items:center;gap:1.5rem;">
            <div style="width:56px;height:56px;background:rgba(201,168,76,.15);border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                <i class="fas fa-calendar-days" style="color:var(--gold);font-size:1.3rem;"></i>
            </div>
            <div>
                <div style="font-size:.72rem;text-transform:uppercase;letter-spacing:.08em;color:var(--gold);font-weight:700;margin-bottom:.2rem;">Upcoming Election</div>
                <h3 style="color:var(--red-dark);font-size:1rem;"><?= htmlspecialchars($pending_election['election_name']) ?></h3>
                <p style="font-size:.82rem;color:var(--gray-400);margin-top:.2rem;">
                    Starts: <?= date('M d, Y g:i A', strtotime($pending_election['start_date'])) ?>
                </p>
            </div>
        </div>
    </div>

    <?php else: ?>
    <div class="card mb-2">
        <div class="card-body">
            <div class="empty-state">
                <i class="fas fa-calendar-xmark"></i>
                <p>No active election at this time. Check back later.</p>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Student Info Card -->
    <div class="card">
        <div class="card-header"><h3><i class="fas fa-circle-user"></i> My Account</h3></div>
        <div class="card-body">
            <div class="vote-summary-item"><span class="position">Full Name</span><span class="candidate"><?= htmlspecialchars($student['full_name']) ?></span></div>
            <div class="vote-summary-item"><span class="position">Student ID</span><span class="candidate"><?= $student['student_id'] ?></span></div>
            <div class="vote-summary-item"><span class="position">Email</span><span class="candidate"><?= htmlspecialchars($student['email']) ?></span></div>
            <div class="vote-summary-item"><span class="position">Year Admitted</span><span class="candidate"><?= $student['year_admitted'] ?></span></div>
            <div class="vote-summary-item">
                <span class="position">Account Status</span>
                <span class="badge <?= $student['is_verified'] ? 'badge-verified' : 'badge-unverified' ?>">
                    <?= $student['is_verified'] ? 'Verified' : 'Pending Verification' ?>
                </span>
            </div>
            <div class="vote-summary-item"><span class="position">Registered</span><span class="candidate"><?= date('M d, Y', strtotime($student['created_at'])) ?></span></div>
        </div>
    </div>
</div>
<style>
@keyframes pulse { 0%,100%{opacity:1;} 50%{opacity:.4;} }
</style>
<script src="<?= BASE_URL ?>assets/js/main.js"></script>
</body>
</html>
