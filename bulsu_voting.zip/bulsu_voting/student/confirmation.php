<?php
// ============================================================
// student/confirmation.php — Vote Confirmation / Summary
// ============================================================
session_start();
define('BASE_URL', '/bulsu_voting/');
require_once __DIR__ . '/../includes/auth_student.php';
require_once __DIR__ . '/../config/db.php';
define('PAGE_TITLE', 'Vote Confirmation');

$db          = getDB();
$student_id  = $_SESSION['student_id'];
$election_id = (int)($_GET['election_id'] ?? 0);

if (!$election_id) { header('Location: dashboard.php'); exit; }

// Get election info
$estmt = $db->prepare("SELECT * FROM elections WHERE election_id=?");
$estmt->execute([$election_id]);
$election = $estmt->fetch();
if (!$election) { header('Location: dashboard.php'); exit; }

// Get student's votes for this election
$vstmt = $db->prepare(
    "SELECT v.voted_at, p.position_name, p.display_order,
            c.full_name AS candidate_name, c.photo
     FROM votes v
     JOIN positions p ON p.position_id = v.position_id
     JOIN candidates c ON c.candidate_id = v.candidate_id
     WHERE v.student_id = ? AND v.election_id = ?
     ORDER BY p.display_order"
);
$vstmt->execute([$student_id, $election_id]);
$my_votes = $vstmt->fetchAll();

// Student info
$sstmt = $db->prepare("SELECT full_name FROM students WHERE student_id=?");
$sstmt->execute([$student_id]);
$student = $sstmt->fetch();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title><?= PAGE_TITLE ?> | BulSU CICT</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body style="background:var(--off-white);">
<nav class="navbar">
    <div class="navbar-brand">
        <img src="<?= BASE_URL ?>assets/images/logo_placeholder.png" alt="BulSU" onerror="this.style.display='none'">
        <div class="brand-text"><div class="brand-title">BulSU CICT Voting</div><div class="brand-sub">Student Portal</div></div>
    </div>
    <ul class="navbar-nav">
        <li><a href="dashboard.php"><i class="fas fa-gauge"></i> Dashboard</a></li>
        <li><a href="<?= BASE_URL ?>logout.php" class="btn-logout"><i class="fas fa-right-from-bracket"></i> Logout</a></li>
    </ul>
</nav>

<div style="max-width:600px;margin:2rem auto;padding:0 1.5rem 3rem;">

    <div class="confirmation-box">
        <!-- Header -->
        <div class="confirmation-header">
            <div class="check-circle"><i class="fas fa-check"></i></div>
            <h2>Vote Submitted!</h2>
            <p style="opacity:.8;font-size:.9rem;margin-top:.4rem;">Your votes have been recorded successfully.</p>
        </div>

        <!-- Body -->
        <div class="confirmation-body">
            <div style="text-align:center;margin-bottom:1.5rem;">
                <div style="font-size:.75rem;text-transform:uppercase;letter-spacing:.06em;color:var(--gray-400);">Election</div>
                <div style="font-family:'Playfair Display',serif;font-size:1.1rem;color:var(--red-dark);margin-top:.2rem;">
                    <?= htmlspecialchars($election['election_name']) ?>
                </div>
                <div style="font-size:.8rem;color:var(--gray-400);margin-top:.2rem;">
                    Voter: <?= htmlspecialchars($student['full_name']) ?> &nbsp;|&nbsp; ID: <?= $student_id ?>
                </div>
            </div>

            <div class="gold-line"></div>
            <h4 style="font-size:.82rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--gray-400);margin-bottom:1rem;">Your Vote Summary</h4>

            <?php if (empty($my_votes)): ?>
            <div class="empty-state"><i class="fas fa-inbox"></i><p>No votes found for this election.</p></div>
            <?php else: ?>
                <?php foreach ($my_votes as $v): ?>
                <div class="vote-summary-item">
                    <div>
                        <div class="position"><?= htmlspecialchars($v['position_name']) ?></div>
                        <div class="candidate"><?= htmlspecialchars($v['candidate_name']) ?></div>
                    </div>
                    <i class="fas fa-check-circle" style="color:#16A34A;"></i>
                </div>
                <?php endforeach; ?>

                <div style="text-align:center;margin-top:1.5rem;padding-top:1rem;border-top:1px solid var(--gray-100);">
                    <div style="font-size:.75rem;color:var(--gray-400);margin-bottom:.3rem;">Timestamp</div>
                    <div style="font-size:.85rem;color:var(--gray-600);">
                        <?= !empty($my_votes) ? date('F d, Y g:i:s A', strtotime($my_votes[0]['voted_at'])) : '' ?>
                    </div>
                </div>
            <?php endif; ?>

            <div class="gold-line"></div>

            <div class="alert alert-info" style="margin-bottom:1rem;">
                <i class="fas fa-shield-halved"></i>
                <span>Your vote is <strong>secure and final</strong>. It cannot be modified or deleted.</span>
            </div>

            <div style="display:flex;gap:.75rem;justify-content:center;">
                <a href="dashboard.php" class="btn btn-primary">
                    <i class="fas fa-house"></i> Back to Dashboard
                </a>
                <button onclick="window.print()" class="btn btn-outline no-print">
                    <i class="fas fa-print"></i> Print
                </button>
            </div>
        </div>
    </div>

    <!-- BulSU Footer -->
    <div style="text-align:center;margin-top:2rem;font-size:.78rem;color:var(--gray-400);">
        <strong style="color:var(--red-dark);">Bulacan State University</strong> — College of Information and Communications Technology<br>
        MBEZ Solutions &copy; <?= date('Y') ?> | Online Voting System
    </div>
</div>

<script src="<?= BASE_URL ?>assets/js/main.js"></script>
</body>
</html>
