<?php
// ============================================================
// admin/results.php — Election Results & Reports
// ============================================================
session_start();
define('BASE_URL', '/bulsu_voting/');
require_once __DIR__ . '/../includes/auth_admin.php';
require_once __DIR__ . '/../config/db.php';
define('PAGE_TITLE', 'Election Results');

$db = getDB();
$elections = $db->query("SELECT * FROM elections ORDER BY election_id DESC")->fetchAll();
$selected  = (int)($_GET['election_id'] ?? ($elections[0]['election_id'] ?? 0));

$results  = [];
$turnout  = null;
$winners  = [];

if ($selected) {
    // Use stored procedure for results
    $stmt = $db->prepare("CALL sp_get_results(?)");
    $stmt->execute([$selected]);
    $raw = $stmt->fetchAll();
    $stmt->closeCursor();

    // Group by position
    foreach ($raw as $row) {
        $results[$row['position_name']][] = $row;
    }

    // Turnout
    $stmt2 = $db->prepare("CALL sp_get_turnout(?)");
    $stmt2->execute([$selected]);
    $turnout = $stmt2->fetch();
    $stmt2->closeCursor();

    // Winners from view
    $stmt3 = $db->prepare("SELECT * FROM vw_winners WHERE election_id=?");
    $stmt3->execute([$selected]);
    $winners_raw = $stmt3->fetchAll();
    foreach ($winners_raw as $w) {
        $winners[$w['position_name']] = $w;
    }
}

$election_info = null;
if ($selected) {
    $ei = $db->prepare("SELECT * FROM elections WHERE election_id=?");
    $ei->execute([$selected]);
    $election_info = $ei->fetch();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title><?= PAGE_TITLE ?> | BulSU CICT</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<nav class="navbar">
    <div class="navbar-brand">
        <img src="<?= BASE_URL ?>assets/images/logo_placeholder.png" alt="BulSU" onerror="this.style.display='none'">
        <div class="brand-text"><div class="brand-title">BulSU CICT Voting</div><div class="brand-sub">Admin Panel</div></div>
    </div>
    <ul class="navbar-nav">
        <li><span style="color:var(--gold-light);font-size:.85rem;"><i class="fas fa-circle-user"></i> <?= htmlspecialchars($_SESSION['admin_name']) ?></span></li>
        <li><a href="<?= BASE_URL ?>logout.php" class="btn-logout"><i class="fas fa-right-from-bracket"></i> Logout</a></li>
    </ul>
</nav>
<div class="layout">
    <aside class="sidebar">
        <div class="sidebar-section-label">Main</div>
        <ul class="sidebar-nav">
            <li><a href="dashboard.php"><i class="fas fa-gauge"></i> Dashboard</a></li>
            <li><a href="elections.php"><i class="fas fa-calendar-check"></i> Elections</a></li>
            <li><a href="positions.php"><i class="fas fa-list-check"></i> Positions</a></li>
            <li><a href="candidates.php"><i class="fas fa-users"></i> Candidates</a></li>
        </ul>
        <div class="sidebar-section-label">Management</div>
        <ul class="sidebar-nav">
            <li><a href="voters.php"><i class="fas fa-user-check"></i> Voters</a></li>
            <li><a href="results.php" class="active"><i class="fas fa-chart-bar"></i> Results</a></li>
            <li><a href="backup.php"><i class="fas fa-database"></i> Backup</a></li>
        </ul>
    </aside>
    <main class="main-content">
        <div class="page-header">
            <div>
                <div class="breadcrumb"><i class="fas fa-home"></i> Admin <span>/ Results</span></div>
                <h1>Election Results</h1>
                <p>Real-time vote count and reports</p>
            </div>
            <div style="display:flex;gap:.75rem;">
                <button class="btn btn-outline no-print" onclick="window.print()"><i class="fas fa-print"></i> Print Report</button>
            </div>
        </div>

        <!-- Election Selector -->
        <div class="card mb-2 no-print">
            <div class="card-body" style="padding:1rem 1.5rem;">
                <form method="GET" style="display:flex;gap:1rem;align-items:center;flex-wrap:wrap;">
                    <label style="font-size:.85rem;font-weight:600;color:var(--gray-600);">Select Election:</label>
                    <select name="election_id" class="form-control" style="width:auto;min-width:260px;" onchange="this.form.submit()">
                        <?php foreach ($elections as $e): ?>
                        <option value="<?= $e['election_id'] ?>" <?= $selected==$e['election_id']?'selected':'' ?>>
                            <?= htmlspecialchars($e['election_name']) ?> (<?= ucfirst($e['status']) ?>)
                        </option>
                        <?php endforeach; ?>
                    </select>
                </form>
            </div>
        </div>

        <?php if ($election_info): ?>
        <!-- Print header (hidden on screen) -->
        <div style="display:none;" id="print-header">
            <div style="text-align:center;margin-bottom:1.5rem;">
                <h2 style="font-size:1.4rem;">Bulacan State University — CICT</h2>
                <h3 style="font-size:1.1rem;"><?= htmlspecialchars($election_info['election_name']) ?></h3>
                <p>Official Election Results | Printed: <?= date('F d, Y g:i A') ?></p>
            </div>
        </div>

        <!-- Turnout Card -->
        <?php if ($turnout): ?>
        <div class="card mb-2" style="border-left:4px solid var(--gold);">
            <div class="card-body" style="padding:1.2rem 1.6rem;">
                <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:1rem;">
                    <div>
                        <div style="font-size:.75rem;text-transform:uppercase;letter-spacing:.06em;color:var(--gray-400);margin-bottom:.3rem;">Voter Turnout</div>
                        <div style="font-family:'Playfair Display',serif;font-size:2rem;color:var(--red-dark);line-height:1;">
                            <?= $turnout['turnout_percentage'] ?? 0 ?>%
                        </div>
                        <div style="font-size:.85rem;color:var(--gray-600);">
                            <?= $turnout['total_voted'] ?> out of <?= $turnout['total_eligible'] ?> eligible voters participated
                        </div>
                    </div>
                    <div style="text-align:right;">
                        <span class="badge badge-<?= $election_info['status'] ?>" style="font-size:.8rem;">
                            <?= ucfirst($election_info['status']) ?>
                        </span>
                        <div style="font-size:.78rem;color:var(--gray-400);margin-top:.4rem;">
                            <?= date('M d, Y', strtotime($election_info['start_date'])) ?>
                            &ndash;
                            <?= date('M d, Y', strtotime($election_info['end_date'])) ?>
                        </div>
                    </div>
                </div>
                <div style="background:var(--gray-100);border-radius:999px;height:10px;overflow:hidden;margin-top:1rem;">
                    <div class="result-bar" data-width="<?= min($turnout['turnout_percentage']??0, 100) ?>"
                         style="height:100%;border-radius:999px;background:linear-gradient(90deg,var(--gold),var(--red));width:0%;transition:width .8s ease;"></div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Winners Summary -->
        <?php if (!empty($winners)): ?>
        <div class="card mb-2">
            <div class="card-header"><h3><i class="fas fa-trophy" style="color:var(--gold);"></i> Winners Summary</h3></div>
            <div class="card-body">
                <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:1rem;">
                    <?php foreach ($winners as $pos => $w): ?>
                    <div style="background:var(--gold-pale);border:1.5px solid var(--gold);border-radius:var(--radius);padding:1rem;text-align:center;">
                        <div style="font-size:.72rem;text-transform:uppercase;letter-spacing:.06em;color:var(--gray-400);margin-bottom:.3rem;"><?= htmlspecialchars($pos) ?></div>
                        <div style="font-weight:700;color:var(--red-dark);font-size:.95rem;"><?= htmlspecialchars($w['winner']) ?></div>
                        <div style="font-size:.8rem;color:var(--gray-600);margin-top:.2rem;"><i class="fas fa-check-circle" style="color:var(--gold);"></i> <?= $w['winning_votes'] ?> votes</div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Detailed Results per Position -->
        <?php if (!empty($results)): ?>
            <?php foreach ($results as $position => $candidates): ?>
            <?php
                $total_pos_votes = array_sum(array_column($candidates, 'total_votes'));
                $max_votes = max(array_column($candidates, 'total_votes'));
            ?>
            <div class="card mb-2">
                <div class="card-header">
                    <h3><i class="fas fa-list-ol"></i> <?= htmlspecialchars($position) ?></h3>
                    <span style="font-size:.8rem;color:var(--gray-400);">Total votes: <?= $total_pos_votes ?></span>
                </div>
                <div class="card-body">
                    <?php foreach ($candidates as $c): ?>
                    <?php
                        $pct = $total_pos_votes > 0 ? round(($c['total_votes'] / $total_pos_votes) * 100, 1) : 0;
                        $is_winner = $c['total_votes'] == $max_votes && $max_votes > 0;
                    ?>
                    <div class="result-candidate" style="margin-bottom:1.1rem;">
                        <div class="result-name">
                            <?= htmlspecialchars($c['candidate_name']) ?>
                            <?php if ($is_winner): ?>
                            <span class="result-winner"><i class="fas fa-crown"></i> Leading</span>
                            <?php endif; ?>
                        </div>
                        <div class="result-bar-wrap">
                            <div class="result-bar" data-width="<?= $pct ?>" style="width:0%;"></div>
                        </div>
                        <div class="result-votes"><?= $c['total_votes'] ?> votes (<?= $pct ?>%)</div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="empty-state card"><div class="card-body"><i class="fas fa-chart-bar" style="font-size:2rem;color:var(--gray-400);display:block;margin-bottom:.75rem;text-align:center;"></i><p style="text-align:center;color:var(--gray-400);">No votes have been cast in this election yet.</p></div></div>
        <?php endif; ?>

        <?php else: ?>
            <div class="empty-state card"><div class="card-body"><i class="fas fa-calendar-xmark" style="font-size:2rem;color:var(--gray-400);display:block;margin-bottom:.75rem;text-align:center;"></i><p style="text-align:center;color:var(--gray-400);">No elections available.</p></div></div>
        <?php endif; ?>
    </main>
</div>
<script src="<?= BASE_URL ?>assets/js/main.js"></script>
</body>
</html>
