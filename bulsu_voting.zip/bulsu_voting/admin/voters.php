<?php
// ============================================================
// admin/voters.php — Voter Management (Verify / CRUD)
// ============================================================
session_start();
define('BASE_URL', '/bulsu_voting/');
require_once __DIR__ . '/../includes/auth_admin.php';
require_once __DIR__ . '/../config/db.php';
define('PAGE_TITLE', 'Manage Voters');

$db    = getDB();
$error = $success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // Verify student
    if ($action === 'verify') {
        $sid = $_POST['student_id'] ?? '';
        $db->prepare("UPDATE students SET is_verified=1 WHERE student_id=?")->execute([$sid]);
        $success = 'Student verified successfully.';
    }
    // Unverify student
    if ($action === 'unverify') {
        $sid = $_POST['student_id'] ?? '';
        $db->prepare("UPDATE students SET is_verified=0 WHERE student_id=?")->execute([$sid]);
        $success = 'Student unverified.';
    }
    // Delete student
    if ($action === 'delete') {
        $sid = $_POST['student_id'] ?? '';
        $vcount = $db->prepare("SELECT COUNT(*) FROM votes WHERE student_id=?");
        $vcount->execute([$sid]);
        if ($vcount->fetchColumn() > 0) {
            $error = 'Cannot delete a student who has already voted.';
        } else {
            $db->prepare("DELETE FROM students WHERE student_id=?")->execute([$sid]);
            $success = 'Student record deleted.';
        }
    }
    // Verify ALL pending
    if ($action === 'verify_all') {
        $db->query("UPDATE students SET is_verified=1 WHERE is_verified=0");
        $success = 'All pending students verified.';
    }
    // Manual add student
    if ($action === 'add_student') {
        $sid   = trim($_POST['student_id'] ?? '');
        $name  = trim($_POST['full_name']  ?? '');
        $email = trim($_POST['email']      ?? '');
        $pw    = trim($_POST['password']   ?? '');

        if (!preg_match('/^\d{10}$/', $sid)) {
            $error = 'Student ID must be exactly 10 digits.';
        } elseif (empty($name) || empty($email) || empty($pw)) {
            $error = 'All fields are required.';
        } else {
            $year = substr($sid, 0, 4);
            $hash = password_hash($pw, PASSWORD_BCRYPT);
            try {
                $db->prepare(
                    "INSERT INTO students (student_id, full_name, email, password, year_admitted, is_verified)
                     VALUES (?, ?, ?, ?, ?, 1)"
                )->execute([$sid, $name, $email, $hash, $year]);
                $success = 'Student added and verified.';
            } catch (PDOException $e) {
                $error = 'Student ID or Email already exists.';
            }
        }
    }
}

// Filter
$filter = $_GET['filter'] ?? 'all';
$search = trim($_GET['search'] ?? '');

$sql = "SELECT s.*,
        (SELECT COUNT(*) FROM votes v WHERE v.student_id=s.student_id) AS vote_count
        FROM students s WHERE 1=1";
$params = [];

if ($filter === 'verified')   { $sql .= " AND s.is_verified=1"; }
if ($filter === 'unverified') { $sql .= " AND s.is_verified=0"; }
if ($search) {
    $sql .= " AND (s.student_id LIKE ? OR s.full_name LIKE ? OR s.email LIKE ?)";
    $params = array_merge($params, ["%$search%", "%$search%", "%$search%"]);
}
$sql .= " ORDER BY s.is_verified ASC, s.created_at DESC";

$stmt = $db->prepare($sql);
$stmt->execute($params);
$students = $stmt->fetchAll();

$total     = $db->query("SELECT COUNT(*) FROM students")->fetchColumn();
$verified  = $db->query("SELECT COUNT(*) FROM students WHERE is_verified=1")->fetchColumn();
$pending   = $db->query("SELECT COUNT(*) FROM students WHERE is_verified=0")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title><?= PAGE_TITLE ?> | BulSU CICT</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<nav class="navbar">
    <div class="navbar-brand">
        <img src="<?= BASE_URL ?>assets/images/logo_placeholder.png" alt="BulSU" onerror="this.style.display='none'">
        <div class="brand-text"><div class="brand-title">BulSU CICT Voting</div><div class="brand-sub">Admin Panel</div></div>
    </div>
    <ul class="navbar-nav">
        <li><span style="color:var(--gold-light);font-size:.85rem;"><i class="fas fa-circle-user"></i> <?= htmlspecialchars($_SESSION['admin_name']) ?></span></li>
        <li><a href="<?= BASE_URL ?>logout.php" class="btn-logout"><i class="fas fa-right-from-bracket"></i> Logout</a></li>
    </ul>
</nav>
<div class="layout">
    <aside class="sidebar">
        <div class="sidebar-section-label">Main</div>
        <ul class="sidebar-nav">
            <li><a href="dashboard.php"><i class="fas fa-gauge"></i> Dashboard</a></li>
            <li><a href="elections.php"><i class="fas fa-calendar-check"></i> Elections</a></li>
            <li><a href="positions.php"><i class="fas fa-list-check"></i> Positions</a></li>
            <li><a href="candidates.php"><i class="fas fa-users"></i> Candidates</a></li>
        </ul>
        <div class="sidebar-section-label">Management</div>
        <ul class="sidebar-nav">
            <li><a href="voters.php" class="active"><i class="fas fa-user-check"></i> Voters</a></li>
            <li><a href="results.php"><i class="fas fa-chart-bar"></i> Results</a></li>
            <li><a href="backup.php"><i class="fas fa-database"></i> Backup</a></li>
        </ul>
    </aside>
    <main class="main-content">
        <div class="page-header">
            <div>
                <div class="breadcrumb"><i class="fas fa-home"></i> Admin <span>/ Voters</span></div>
                <h1>Voters</h1>
                <p>Manage and verify CICT student voter accounts</p>
            </div>
            <div style="display:flex;gap:.75rem;flex-wrap:wrap;">
                <?php if ($pending > 0): ?>
                <form method="POST" style="display:inline;">
                    <input type="hidden" name="action" value="verify_all">
                    <button class="btn btn-success confirm-delete" data-confirm="Verify all <?= $pending ?> pending students?">
                        <i class="fas fa-check-double"></i> Verify All Pending
                    </button>
                </form>
                <?php endif; ?>
                <button class="btn btn-primary" data-modal-open="modal-add"><i class="fas fa-user-plus"></i> Add Student</button>
            </div>
        </div>

        <?php if ($error):   ?><div class="alert alert-error"><i class="fas fa-circle-exclamation"></i><?= htmlspecialchars($error) ?></div><?php endif; ?>
        <?php if ($success): ?><div class="alert alert-success"><i class="fas fa-circle-check"></i><?= htmlspecialchars($success) ?></div><?php endif; ?>

        <!-- Stats -->
        <div class="stats-grid" style="grid-template-columns:repeat(3,1fr);margin-bottom:1.5rem;">
            <div class="stat-card">
                <div class="stat-icon blue"><i class="fas fa-users"></i></div>
                <div><div class="stat-value"><?= $total ?></div><div class="stat-label">Total Registered</div></div>
            </div>
            <div class="stat-card">
                <div class="stat-icon green"><i class="fas fa-user-check"></i></div>
                <div><div class="stat-value"><?= $verified ?></div><div class="stat-label">Verified</div></div>
            </div>
            <div class="stat-card">
                <div class="stat-icon gold"><i class="fas fa-hourglass-half"></i></div>
                <div><div class="stat-value"><?= $pending ?></div><div class="stat-label">Pending</div></div>
            </div>
        </div>

        <!-- Filter & Search -->
        <div class="card mb-2">
            <div class="card-body" style="padding:1rem 1.5rem;">
                <form method="GET" style="display:flex;gap:1rem;align-items:center;flex-wrap:wrap;">
                    <div style="display:flex;gap:.5rem;">
                        <?php foreach (['all'=>'All','verified'=>'Verified','unverified'=>'Pending'] as $k=>$v): ?>
                        <a href="?filter=<?= $k ?>" class="btn btn-sm <?= $filter===$k ? 'btn-primary' : 'btn-outline' ?>"><?= $v ?></a>
                        <?php endforeach; ?>
                    </div>
                    <div class="input-icon-wrap" style="flex:1;min-width:200px;">
                        <i class="fas fa-search input-icon"></i>
                        <input type="text" name="search" class="form-control" placeholder="Search by name, ID, or email..." value="<?= htmlspecialchars($search) ?>">
                    </div>
                    <input type="hidden" name="filter" value="<?= $filter ?>">
                    <button class="btn btn-outline btn-sm"><i class="fas fa-search"></i> Search</button>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-header"><h3><i class="fas fa-users"></i> Student Voters (<?= count($students) ?>)</h3></div>
            <div class="table-wrap">
                <?php if (empty($students)): ?>
                    <div class="empty-state"><i class="fas fa-users"></i><p>No students found.</p></div>
                <?php else: ?>
                <table>
                    <thead>
                        <tr><th>Student ID</th><th>Full Name</th><th>Email</th><th>Year</th><th>Status</th><th>Votes Cast</th><th>Registered</th><th>Actions</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($students as $s): ?>
                        <tr>
                            <td><strong><?= $s['student_id'] ?></strong></td>
                            <td><?= htmlspecialchars($s['full_name']) ?></td>
                            <td style="font-size:.82rem;"><?= htmlspecialchars($s['email']) ?></td>
                            <td><?= $s['year_admitted'] ?></td>
                            <td>
                                <span class="badge <?= $s['is_verified'] ? 'badge-verified' : 'badge-unverified' ?>">
                                    <?= $s['is_verified'] ? 'Verified' : 'Pending' ?>
                                </span>
                            </td>
                            <td><?= $s['vote_count'] ?></td>
                            <td style="font-size:.78rem;color:var(--gray-400);"><?= date('M d, Y', strtotime($s['created_at'])) ?></td>
                            <td class="td-actions">
                                <?php if (!$s['is_verified']): ?>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="action" value="verify">
                                    <input type="hidden" name="student_id" value="<?= $s['student_id'] ?>">
                                    <button class="btn btn-success btn-sm"><i class="fas fa-check"></i> Verify</button>
                                </form>
                                <?php else: ?>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="action" value="unverify">
                                    <input type="hidden" name="student_id" value="<?= $s['student_id'] ?>">
                                    <button class="btn btn-outline btn-sm"><i class="fas fa-ban"></i></button>
                                </form>
                                <?php endif; ?>
                                <?php if ($s['vote_count'] == 0): ?>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="student_id" value="<?= $s['student_id'] ?>">
                                    <button class="btn btn-danger btn-sm confirm-delete" data-confirm="Delete this student account?"><i class="fas fa-trash"></i></button>
                                </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>
        </div>
    </main>
</div>

<!-- Add Student Modal -->
<div class="modal-overlay" id="modal-add">
    <div class="modal">
        <div class="modal-header"><h3><i class="fas fa-user-plus"></i> Add Student</h3><button class="modal-close">&times;</button></div>
        <form method="POST">
            <input type="hidden" name="action" value="add_student">
            <div class="modal-body">
                <div class="form-group">
                    <label>Student ID</label>
                    <input type="text" name="student_id" id="student_id" class="form-control" placeholder="e.g. 2024100815" maxlength="10" required>
                </div>
                <div class="form-group">
                    <label>Full Name</label>
                    <input type="text" name="full_name" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Temporary Password</label>
                    <input type="text" name="password" class="form-control" placeholder="Min 8 characters" required>
                </div>
                <input type="hidden" name="year_admitted" id="year_admitted">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" data-modal-close>Cancel</button>
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Add & Verify</button>
            </div>
        </form>
    </div>
</div>

<script src="<?= BASE_URL ?>assets/js/main.js"></script>
</body>
</html>
