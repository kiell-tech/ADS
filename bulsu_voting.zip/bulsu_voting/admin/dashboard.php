<?php
// ============================================================
// admin/dashboard.php — Admin Dashboard
// ============================================================
session_start();
define('BASE_URL', '/bulsu_voting/');
require_once __DIR__ . '/../includes/auth_admin.php';
require_once __DIR__ . '/../config/db.php';
define('PAGE_TITLE', 'Admin Dashboard');

$db = getDB();

// ── Stats ──
$total_students  = $db->query("SELECT COUNT(*) FROM students")->fetchColumn();
$verified        = $db->query("SELECT COUNT(*) FROM students WHERE is_verified=1")->fetchColumn();
$pending         = $db->query("SELECT COUNT(*) FROM students WHERE is_verified=0")->fetchColumn();
$total_elections = $db->query("SELECT COUNT(*) FROM elections")->fetchColumn();
$active_election = $db->query("SELECT COUNT(*) FROM elections WHERE status='active'")->fetchColumn();
$total_candidates= $db->query("SELECT COUNT(*) FROM candidates")->fetchColumn();
$total_votes     = $db->query("SELECT COUNT(*) FROM votes")->fetchColumn();

// ── Active election info ──
$active = $db->query("SELECT * FROM elections WHERE status='active' ORDER BY election_id DESC LIMIT 1")->fetch();

// ── Recent vote logs ──
$logs = $db->query(
    "SELECT vl.*, s.full_name AS voter_name, c.full_name AS candidate_name, p.position_name
     FROM vote_logs vl
     JOIN students s ON s.student_id = vl.student_id
     JOIN candidates c ON c.candidate_id = vl.candidate_id
     JOIN positions p ON p.position_id = vl.position_id
     ORDER BY vl.logged_at DESC LIMIT 8"
)->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title><?= PAGE_TITLE ?> | BulSU CICT</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>

<!-- Navbar -->
<nav class="navbar">
    <div class="navbar-brand">
        <img src="<?= BASE_URL ?>assets/images/logo_placeholder.png" alt="BulSU" onerror="this.style.display='none'">
        <div class="brand-text">
            <div class="brand-title">BulSU CICT Voting</div>
            <div class="brand-sub">Admin Panel</div>
        </div>
    </div>
    <ul class="navbar-nav">
        <li><span style="color:var(--gold-light);font-size:.85rem;"><i class="fas fa-circle-user"></i> <?= htmlspecialchars($_SESSION['admin_name']) ?></span></li>
        <li><a href="<?= BASE_URL ?>logout.php" class="btn-logout"><i class="fas fa-right-from-bracket"></i> Logout</a></li>
    </ul>
</nav>

<div class="layout">
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-section-label">Main</div>
        <ul class="sidebar-nav">
            <li><a href="dashboard.php" class="active"><i class="fas fa-gauge"></i> Dashboard</a></li>
            <li><a href="elections.php"><i class="fas fa-calendar-check"></i> Elections</a></li>
            <li><a href="positions.php"><i class="fas fa-list-check"></i> Positions</a></li>
            <li><a href="candidates.php"><i class="fas fa-users"></i> Candidates</a></li>
        </ul>
        <div class="sidebar-section-label">Management</div>
        <ul class="sidebar-nav">
            <li><a href="voters.php"><i class="fas fa-user-check"></i> Voters</a></li>
            <li><a href="results.php"><i class="fas fa-chart-bar"></i> Results</a></li>
            <li><a href="backup.php"><i class="fas fa-database"></i> Backup</a></li>
        </ul>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <div class="page-header">
            <div>
                <div class="breadcrumb"><i class="fas fa-home"></i> <span>Dashboard</span></div>
                <h1>Admin Dashboard</h1>
                <p>Welcome back, <?= htmlspecialchars($_SESSION['admin_name']) ?>!</p>
            </div>
        </div>

        <!-- Stat Cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon red"><i class="fas fa-users"></i></div>
                <div>
                    <div class="stat-value"><?= $total_students ?></div>
                    <div class="stat-label">Total Students</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon green"><i class="fas fa-user-check"></i></div>
                <div>
                    <div class="stat-value"><?= $verified ?></div>
                    <div class="stat-label">Verified Voters</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon gold"><i class="fas fa-hourglass-half"></i></div>
                <div>
                    <div class="stat-value"><?= $pending ?></div>
                    <div class="stat-label">Pending Approval</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon blue"><i class="fas fa-ballot-check"></i></div>
                <div>
                    <div class="stat-value"><?= $total_votes ?></div>
                    <div class="stat-label">Votes Cast</div>
                </div>
            </div>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:1.5rem;flex-wrap:wrap;">

            <!-- Active Election Status -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-calendar-check"></i> Active Election</h3>
                    <a href="elections.php" class="btn btn-outline btn-sm">Manage</a>
                </div>
                <div class="card-body">
                    <?php if ($active): ?>
                        <h3 style="color:var(--red-dark); margin-bottom:.5rem;"><?= htmlspecialchars($active['election_name']) ?></h3>
                        <p style="font-size:.85rem; color:var(--gray-400);">
                            <i class="fas fa-calendar-day"></i>
                            <?= date('M d, Y g:i A', strtotime($active['start_date'])) ?>
                            &rarr; <?= date('M d, Y g:i A', strtotime($active['end_date'])) ?>
                        </p>
                        <div class="gold-line"></div>
                        <?php
                            // Turnout for active election
                            $stmt = $db->prepare("CALL sp_get_turnout(?)");
                            $stmt->execute([$active['election_id']]);
                            $turnout = $stmt->fetch();
                            $pct = $turnout['turnout_percentage'] ?? 0;
                        ?>
                        <p style="font-size:.82rem; color:var(--gray-600); margin-bottom:.5rem;">
                            Voter Turnout: <strong><?= $turnout['total_voted'] ?></strong> / <?= $turnout['total_eligible'] ?> eligible voters
                        </p>
                        <div style="background:var(--gray-100);border-radius:999px;height:10px;overflow:hidden;">
                            <div style="height:100%;width:<?= min($pct,100) ?>%;background:linear-gradient(90deg,var(--gold),var(--red));border-radius:999px;transition:width .6s ease;"></div>
                        </div>
                        <p style="text-align:right; font-size:.8rem; margin-top:.3rem; color:var(--red);font-weight:600;"><?= $pct ?>%</p>
                    <?php else: ?>
                        <div class="empty-state">
                            <i class="fas fa-calendar-xmark"></i>
                            <p>No active election at this time.</p>
                            <a href="elections.php" class="btn btn-primary btn-sm mt-2">Create Election</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Quick Stats -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-chart-pie"></i> Quick Summary</h3>
                </div>
                <div class="card-body">
                    <div class="vote-summary-item">
                        <span class="position">Total Elections</span>
                        <span class="candidate"><?= $total_elections ?></span>
                    </div>
                    <div class="vote-summary-item">
                        <span class="position">Active Elections</span>
                        <span class="candidate"><?= $active_election ?></span>
                    </div>
                    <div class="vote-summary-item">
                        <span class="position">Total Candidates</span>
                        <span class="candidate"><?= $total_candidates ?></span>
                    </div>
                    <div class="vote-summary-item">
                        <span class="position">Total Votes Cast</span>
                        <span class="candidate"><?= $total_votes ?></span>
                    </div>
                    <div class="vote-summary-item">
                        <span class="position">Pending Verifications</span>
                        <span class="candidate" style="color:<?= $pending > 0 ? 'var(--red)' : 'inherit' ?>"><?= $pending ?></span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Vote Logs -->
        <div class="card mt-3">
            <div class="card-header">
                <h3><i class="fas fa-clock-rotate-left"></i> Recent Vote Activity</h3>
            </div>
            <div class="table-wrap">
                <?php if (empty($logs)): ?>
                    <div class="empty-state"><i class="fas fa-inbox"></i><p>No votes recorded yet.</p></div>
                <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Student</th>
                            <th>Position</th>
                            <th>Voted For</th>
                            <th>Time</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($logs as $log): ?>
                        <tr>
                            <td><?= htmlspecialchars($log['voter_name']) ?><br>
                                <small style="color:var(--gray-400);"><?= $log['student_id'] ?></small></td>
                            <td><?= htmlspecialchars($log['position_name']) ?></td>
                            <td><?= htmlspecialchars($log['candidate_name']) ?></td>
                            <td style="font-size:.8rem; color:var(--gray-400);"><?= date('M d, Y g:i A', strtotime($log['logged_at'])) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>
        </div>
    </main>
</div>
<script src="<?= BASE_URL ?>assets/js/main.js"></script>
</body>
</html>
