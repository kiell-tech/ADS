<?php
// ============================================================
// admin/positions.php — Positions CRUD
// ============================================================
session_start();
define('BASE_URL', '/bulsu_voting/');
require_once __DIR__ . '/../includes/auth_admin.php';
require_once __DIR__ . '/../config/db.php';
define('PAGE_TITLE', 'Manage Positions');

$db    = getDB();
$error = $success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'create') {
        $eid   = (int)($_POST['election_id']    ?? 0);
        $name  = trim($_POST['position_name']  ?? '');
        $max   = (int)($_POST['max_candidates'] ?? 4);
        $order = (int)($_POST['display_order']  ?? 1);
        if (!$eid || empty($name)) { $error = 'Election and position name are required.'; }
        else {
            $db->prepare("INSERT INTO positions (election_id, position_name, max_candidates, display_order) VALUES (?,?,?,?)")
               ->execute([$eid, $name, $max, $order]);
            $success = 'Position added.';
        }
    }
    if ($action === 'update') {
        $id    = (int)($_POST['position_id']    ?? 0);
        $name  = trim($_POST['position_name']  ?? '');
        $max   = (int)($_POST['max_candidates'] ?? 4);
        $order = (int)($_POST['display_order']  ?? 1);
        $db->prepare("UPDATE positions SET position_name=?, max_candidates=?, display_order=? WHERE position_id=?")
           ->execute([$name, $max, $order, $id]);
        $success = 'Position updated.';
    }
    if ($action === 'delete') {
        $id = (int)($_POST['position_id'] ?? 0);
        $vcount = $db->prepare("SELECT COUNT(*) FROM votes WHERE position_id=?");
        $vcount->execute([$id]);
        if ($vcount->fetchColumn() > 0) { $error = 'Cannot delete position with existing votes.'; }
        else {
            $db->prepare("DELETE FROM positions WHERE position_id=?")->execute([$id]);
            $success = 'Position deleted.';
        }
    }
}

$filter_election = (int)($_GET['election_id'] ?? 0);
$elections = $db->query("SELECT * FROM elections ORDER BY election_id DESC")->fetchAll();

$pos_sql = "SELECT p.*, e.election_name,
            (SELECT COUNT(*) FROM candidates c WHERE c.position_id=p.position_id) AS candidate_count
            FROM positions p JOIN elections e ON e.election_id=p.election_id";
if ($filter_election) {
    $pstmt = $db->prepare($pos_sql . " WHERE p.election_id=? ORDER BY p.display_order");
    $pstmt->execute([$filter_election]);
} else {
    $pstmt = $db->query($pos_sql . " ORDER BY e.election_id DESC, p.display_order");
}
$positions = $pstmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title><?= PAGE_TITLE ?> | BulSU CICT</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<nav class="navbar">
    <div class="navbar-brand">
        <img src="<?= BASE_URL ?>assets/images/logo_placeholder.png" alt="BulSU" onerror="this.style.display='none'">
        <div class="brand-text"><div class="brand-title">BulSU CICT Voting</div><div class="brand-sub">Admin Panel</div></div>
    </div>
    <ul class="navbar-nav">
        <li><span style="color:var(--gold-light);font-size:.85rem;"><i class="fas fa-circle-user"></i> <?= htmlspecialchars($_SESSION['admin_name']) ?></span></li>
        <li><a href="<?= BASE_URL ?>logout.php" class="btn-logout"><i class="fas fa-right-from-bracket"></i> Logout</a></li>
    </ul>
</nav>
<div class="layout">
    <aside class="sidebar">
        <div class="sidebar-section-label">Main</div>
        <ul class="sidebar-nav">
            <li><a href="dashboard.php"><i class="fas fa-gauge"></i> Dashboard</a></li>
            <li><a href="elections.php"><i class="fas fa-calendar-check"></i> Elections</a></li>
            <li><a href="positions.php" class="active"><i class="fas fa-list-check"></i> Positions</a></li>
            <li><a href="candidates.php"><i class="fas fa-users"></i> Candidates</a></li>
        </ul>
        <div class="sidebar-section-label">Management</div>
        <ul class="sidebar-nav">
            <li><a href="voters.php"><i class="fas fa-user-check"></i> Voters</a></li>
            <li><a href="results.php"><i class="fas fa-chart-bar"></i> Results</a></li>
            <li><a href="backup.php"><i class="fas fa-database"></i> Backup</a></li>
        </ul>
    </aside>
    <main class="main-content">
        <div class="page-header">
            <div>
                <div class="breadcrumb"><i class="fas fa-home"></i> Admin <span>/ Positions</span></div>
                <h1>Positions</h1>
                <p>Manage election positions (auto-created with elections)</p>
            </div>
            <button class="btn btn-primary" data-modal-open="modal-create"><i class="fas fa-plus"></i> Add Position</button>
        </div>

        <?php if ($error):   ?><div class="alert alert-error"><i class="fas fa-circle-exclamation"></i><?= htmlspecialchars($error) ?></div><?php endif; ?>
        <?php if ($success): ?><div class="alert alert-success"><i class="fas fa-circle-check"></i><?= htmlspecialchars($success) ?></div><?php endif; ?>

        <div class="card mb-2">
            <div class="card-body" style="padding:1rem 1.5rem;">
                <form method="GET" style="display:flex;gap:1rem;align-items:center;flex-wrap:wrap;">
                    <label style="font-size:.85rem;font-weight:600;color:var(--gray-600);">Filter by Election:</label>
                    <select name="election_id" class="form-control" style="width:auto;min-width:240px;" onchange="this.form.submit()">
                        <option value="0">— All Elections —</option>
                        <?php foreach ($elections as $e): ?>
                        <option value="<?= $e['election_id'] ?>" <?= $filter_election==$e['election_id']?'selected':'' ?>><?= htmlspecialchars($e['election_name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-header"><h3><i class="fas fa-list-check"></i> Positions List</h3></div>
            <div class="table-wrap">
                <?php if (empty($positions)): ?>
                    <div class="empty-state"><i class="fas fa-list"></i><p>No positions found. They are auto-created with elections.</p></div>
                <?php else: ?>
                <table>
                    <thead><tr><th>#</th><th>Position Name</th><th>Election</th><th>Max Candidates</th><th>Candidates Added</th><th>Order</th><th>Actions</th></tr></thead>
                    <tbody>
                        <?php foreach ($positions as $p): ?>
                        <tr>
                            <td><?= $p['position_id'] ?></td>
                            <td><strong><?= htmlspecialchars($p['position_name']) ?></strong></td>
                            <td style="font-size:.82rem;color:var(--gray-400);"><?= htmlspecialchars($p['election_name']) ?></td>
                            <td><?= $p['max_candidates'] ?></td>
                            <td>
                                <span class="badge <?= $p['candidate_count']>0?'badge-verified':'badge-unverified' ?>">
                                    <?= $p['candidate_count'] ?> / <?= $p['max_candidates'] ?>
                                </span>
                            </td>
                            <td><?= $p['display_order'] ?></td>
                            <td class="td-actions">
                                <button class="btn btn-outline btn-sm" data-modal-open="modal-edit"
                                    data-edit='<?= json_encode(["position_id"=>$p["position_id"],"position_name"=>$p["position_name"],"max_candidates"=>$p["max_candidates"],"display_order"=>$p["display_order"]]) ?>'>
                                    <i class="fas fa-pen"></i>
                                </button>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="position_id" value="<?= $p['position_id'] ?>">
                                    <button class="btn btn-danger btn-sm confirm-delete" data-confirm="Delete this position?"><i class="fas fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>
        </div>
    </main>
</div>

<!-- Create Modal -->
<div class="modal-overlay" id="modal-create">
    <div class="modal">
        <div class="modal-header"><h3><i class="fas fa-plus"></i> Add Position</h3><button class="modal-close">&times;</button></div>
        <form method="POST">
            <input type="hidden" name="action" value="create">
            <div class="modal-body">
                <div class="form-group">
                    <label>Election</label>
                    <select name="election_id" class="form-control" required>
                        <option value="">— Select Election —</option>
                        <?php foreach ($elections as $e): ?>
                        <option value="<?= $e['election_id'] ?>"><?= htmlspecialchars($e['election_name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Position Name</label>
                    <input type="text" name="position_name" class="form-control" placeholder="e.g. CICT LSC President" required>
                </div>
                <div class="form-group">
                    <label>Max Candidates</label>
                    <input type="number" name="max_candidates" class="form-control" value="4" min="1" max="10">
                </div>
                <div class="form-group">
                    <label>Display Order</label>
                    <input type="number" name="display_order" class="form-control" value="1" min="1">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" data-modal-close>Cancel</button>
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Add Position</button>
            </div>
        </form>
    </div>
</div>

<!-- Edit Modal -->
<div class="modal-overlay" id="modal-edit">
    <div class="modal">
        <div class="modal-header"><h3><i class="fas fa-pen"></i> Edit Position</h3><button class="modal-close">&times;</button></div>
        <form method="POST">
            <input type="hidden" name="action" value="update">
            <input type="hidden" name="position_id">
            <div class="modal-body">
                <div class="form-group"><label>Position Name</label><input type="text" name="position_name" class="form-control" required></div>
                <div class="form-group"><label>Max Candidates</label><input type="number" name="max_candidates" class="form-control" min="1" max="10"></div>
                <div class="form-group"><label>Display Order</label><input type="number" name="display_order" class="form-control" min="1"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" data-modal-close>Cancel</button>
                <button type="submit" class="btn btn-gold"><i class="fas fa-save"></i> Save</button>
            </div>
        </form>
    </div>
</div>
<script src="<?= BASE_URL ?>assets/js/main.js"></script>
</body>
</html>
