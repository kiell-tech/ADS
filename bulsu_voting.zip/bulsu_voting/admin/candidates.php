<?php
// ============================================================
// admin/candidates.php — Candidates CRUD
// ============================================================
session_start();
define('BASE_URL', '/bulsu_voting/');
require_once __DIR__ . '/../includes/auth_admin.php';
require_once __DIR__ . '/../config/db.php';
define('PAGE_TITLE', 'Manage Candidates');

$db    = getDB();
$error = $success = '';

// ── Handle POST ──
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'create') {
        $election_id = (int)($_POST['election_id'] ?? 0);
        $position_id = (int)($_POST['position_id'] ?? 0);
        $student_id  = trim($_POST['student_id']   ?? '');
        $full_name   = trim($_POST['full_name']    ?? '');
        $platform    = trim($_POST['platform']     ?? '');

        if (empty($election_id) || empty($position_id) || empty($student_id) || empty($full_name)) {
            $error = 'All required fields must be filled.';
        } else {
            // Handle photo upload
            $photo = null;
            if (!empty($_FILES['photo']['name'])) {
                $ext   = strtolower(pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION));
                $allowed = ['jpg','jpeg','png','webp'];
                if (!in_array($ext, $allowed)) {
                    $error = 'Only JPG, PNG, WEBP images are allowed.';
                } else {
                    $photo = 'candidate_' . time() . '_' . rand(100,999) . '.' . $ext;
                    $dest  = __DIR__ . '/../assets/images/' . $photo;
                    if (!move_uploaded_file($_FILES['photo']['tmp_name'], $dest)) {
                        $photo = null;
                    }
                }
            }

            if (empty($error)) {
                try {
                    $stmt = $db->prepare(
                        "INSERT INTO candidates (election_id, position_id, student_id, full_name, platform, photo)
                         VALUES (?, ?, ?, ?, ?, ?)"
                    );
                    $stmt->execute([$election_id, $position_id, $student_id, $full_name, $platform, $photo]);
                    $success = 'Candidate added successfully!';
                } catch (PDOException $e) {
                    if ($e->getCode() == 23000) {
                        $error = 'This student is already registered as a candidate for this position.';
                    } elseif (strpos($e->getMessage(), 'Maximum number') !== false) {
                        $error = 'Maximum candidates for this position reached (max 4).';
                    } else {
                        $error = 'Error: ' . $e->getMessage();
                    }
                }
            }
        }
    }

    if ($action === 'update') {
        $id       = (int)($_POST['candidate_id'] ?? 0);
        $name     = trim($_POST['full_name']     ?? '');
        $platform = trim($_POST['platform']      ?? '');

        $stmt = $db->prepare("UPDATE candidates SET full_name=?, platform=? WHERE candidate_id=?");
        $stmt->execute([$name, $platform, $id]);
        $success = 'Candidate updated.';
    }

    if ($action === 'delete') {
        $id = (int)($_POST['candidate_id'] ?? 0);
        $votes = $db->prepare("SELECT COUNT(*) FROM votes WHERE candidate_id=?");
        $votes->execute([$id]);
        if ($votes->fetchColumn() > 0) {
            $error = 'Cannot delete a candidate who has received votes.';
        } else {
            $db->prepare("DELETE FROM candidates WHERE candidate_id=?")->execute([$id]);
            $success = 'Candidate removed.';
        }
    }
}

// ── Filter by election ──
$filter_election = (int)($_GET['election_id'] ?? 0);

// ── Fetch elections ──
$elections = $db->query("SELECT * FROM elections ORDER BY election_id DESC")->fetchAll();

// ── Fetch candidates ──
$cand_sql = "SELECT c.*, e.election_name, p.position_name
             FROM candidates c
             JOIN elections e ON e.election_id = c.election_id
             JOIN positions  p ON p.position_id  = c.position_id";
if ($filter_election) {
    $cand_stmt = $db->prepare($cand_sql . " WHERE c.election_id=? ORDER BY p.display_order, c.full_name");
    $cand_stmt->execute([$filter_election]);
} else {
    $cand_stmt = $db->query($cand_sql . " ORDER BY e.election_id DESC, p.display_order, c.full_name");
}
$candidates = $cand_stmt->fetchAll();

// ── Fetch positions for selected election ──
$positions = [];
if ($filter_election) {
    $pstmt = $db->prepare("SELECT * FROM positions WHERE election_id=? ORDER BY display_order");
    $pstmt->execute([$filter_election]);
    $positions = $pstmt->fetchAll();
}

// ── Fetch verified students for dropdown ──
$students = $db->query("SELECT student_id, full_name FROM students WHERE is_verified=1 ORDER BY full_name")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title><?= PAGE_TITLE ?> | BulSU CICT</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<nav class="navbar">
    <div class="navbar-brand">
        <img src="<?= BASE_URL ?>assets/images/logo_placeholder.png" alt="BulSU" onerror="this.style.display:'none'">
        <div class="brand-text">
            <div class="brand-title">BulSU CICT Voting</div>
            <div class="brand-sub">Admin Panel</div>
        </div>
    </div>
    <ul class="navbar-nav">
        <li><span style="color:var(--gold-light);font-size:.85rem;"><i class="fas fa-circle-user"></i> <?= htmlspecialchars($_SESSION['admin_name']) ?></span></li>
        <li><a href="<?= BASE_URL ?>logout.php" class="btn-logout"><i class="fas fa-right-from-bracket"></i> Logout</a></li>
    </ul>
</nav>
<div class="layout">
    <aside class="sidebar">
        <div class="sidebar-section-label">Main</div>
        <ul class="sidebar-nav">
            <li><a href="dashboard.php"><i class="fas fa-gauge"></i> Dashboard</a></li>
            <li><a href="elections.php"><i class="fas fa-calendar-check"></i> Elections</a></li>
            <li><a href="positions.php"><i class="fas fa-list-check"></i> Positions</a></li>
            <li><a href="candidates.php" class="active"><i class="fas fa-users"></i> Candidates</a></li>
        </ul>
        <div class="sidebar-section-label">Management</div>
        <ul class="sidebar-nav">
            <li><a href="voters.php"><i class="fas fa-user-check"></i> Voters</a></li>
            <li><a href="results.php"><i class="fas fa-chart-bar"></i> Results</a></li>
            <li><a href="backup.php"><i class="fas fa-database"></i> Backup</a></li>
        </ul>
    </aside>
    <main class="main-content">
        <div class="page-header">
            <div>
                <div class="breadcrumb"><i class="fas fa-home"></i> Admin <span>/ Candidates</span></div>
                <h1>Candidates</h1>
                <p>Add and manage election candidates</p>
            </div>
            <button class="btn btn-primary" data-modal-open="modal-create"><i class="fas fa-plus"></i> Add Candidate</button>
        </div>

        <?php if ($error):   ?><div class="alert alert-error"><i class="fas fa-circle-exclamation"></i><?= htmlspecialchars($error) ?></div><?php endif; ?>
        <?php if ($success): ?><div class="alert alert-success"><i class="fas fa-circle-check"></i><?= htmlspecialchars($success) ?></div><?php endif; ?>

        <!-- Filter -->
        <div class="card mb-2">
            <div class="card-body" style="padding:1rem 1.5rem;">
                <form method="GET" style="display:flex;gap:1rem;align-items:center;flex-wrap:wrap;">
                    <label style="font-size:.85rem;font-weight:600;color:var(--gray-600);">Filter by Election:</label>
                    <select name="election_id" class="form-control" style="width:auto;min-width:240px;" onchange="this.form.submit()">
                        <option value="0">— All Elections —</option>
                        <?php foreach ($elections as $e): ?>
                        <option value="<?= $e['election_id'] ?>" <?= $filter_election==$e['election_id']?'selected':'' ?>>
                            <?= htmlspecialchars($e['election_name']) ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-header"><h3><i class="fas fa-users"></i> Candidates List</h3></div>
            <div class="table-wrap">
                <?php if (empty($candidates)): ?>
                    <div class="empty-state"><i class="fas fa-users"></i><p>No candidates added yet.</p></div>
                <?php else: ?>
                <table>
                    <thead>
                        <tr><th>Photo</th><th>Name</th><th>Student ID</th><th>Position</th><th>Election</th><th>Actions</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($candidates as $c): ?>
                        <tr>
                            <td>
                                <?php if ($c['photo']): ?>
                                    <img src="<?= BASE_URL ?>assets/images/<?= htmlspecialchars($c['photo']) ?>"
                                         style="width:36px;height:36px;border-radius:50%;object-fit:cover;border:2px solid var(--gold);">
                                <?php else: ?>
                                    <div style="width:36px;height:36px;border-radius:50%;background:var(--gray-100);display:flex;align-items:center;justify-content:center;border:2px solid var(--gray-200);">
                                        <i class="fas fa-user" style="color:var(--gray-400);"></i>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td><strong><?= htmlspecialchars($c['full_name']) ?></strong></td>
                            <td><?= $c['student_id'] ?></td>
                            <td><?= htmlspecialchars($c['position_name']) ?></td>
                            <td style="font-size:.8rem;color:var(--gray-400);"><?= htmlspecialchars($c['election_name']) ?></td>
                            <td class="td-actions">
                                <button class="btn btn-outline btn-sm"
                                    data-modal-open="modal-edit"
                                    data-edit='<?= json_encode(["candidate_id"=>$c["candidate_id"],"full_name"=>$c["full_name"],"platform"=>$c["platform"]]) ?>'>
                                    <i class="fas fa-pen"></i>
                                </button>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="candidate_id" value="<?= $c['candidate_id'] ?>">
                                    <button type="submit" class="btn btn-danger btn-sm confirm-delete"
                                        data-confirm="Remove this candidate?"><i class="fas fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>
        </div>
    </main>
</div>

<!-- CREATE Modal -->
<div class="modal-overlay" id="modal-create">
    <div class="modal">
        <div class="modal-header"><h3><i class="fas fa-user-plus"></i> Add Candidate</h3><button class="modal-close">&times;</button></div>
        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="action" value="create">
            <div class="modal-body">
                <div class="form-group">
                    <label>Election</label>
                    <select name="election_id" id="create_election" class="form-control" required onchange="loadPositions(this.value)">
                        <option value="">— Select Election —</option>
                        <?php foreach ($elections as $e): ?>
                        <option value="<?= $e['election_id'] ?>"><?= htmlspecialchars($e['election_name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Position</label>
                    <select name="position_id" id="create_position" class="form-control" required>
                        <option value="">— Select Election first —</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Student (Candidate)</label>
                    <select name="student_id" class="form-control" required>
                        <option value="">— Select Verified Student —</option>
                        <?php foreach ($students as $s): ?>
                        <option value="<?= $s['student_id'] ?>"><?= htmlspecialchars($s['full_name']) ?> (<?= $s['student_id'] ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Display Name</label>
                    <input type="text" name="full_name" class="form-control" placeholder="Candidate full name" required>
                </div>
                <div class="form-group">
                    <label>Platform / Bio <small style="color:var(--gray-400);">(optional)</small></label>
                    <textarea name="platform" class="form-control" placeholder="Brief platform or bio..."></textarea>
                </div>
                <div class="form-group">
                    <label>Photo <small style="color:var(--gray-400);">(optional, JPG/PNG)</small></label>
                    <input type="file" name="photo" class="form-control" accept="image/*">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" data-modal-close>Cancel</button>
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Add Candidate</button>
            </div>
        </form>
    </div>
</div>

<!-- EDIT Modal -->
<div class="modal-overlay" id="modal-edit">
    <div class="modal">
        <div class="modal-header"><h3><i class="fas fa-pen"></i> Edit Candidate</h3><button class="modal-close">&times;</button></div>
        <form method="POST">
            <input type="hidden" name="action" value="update">
            <input type="hidden" name="candidate_id">
            <div class="modal-body">
                <div class="form-group">
                    <label>Full Name</label>
                    <input type="text" name="full_name" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Platform / Bio</label>
                    <textarea name="platform" class="form-control"></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" data-modal-close>Cancel</button>
                <button type="submit" class="btn btn-gold"><i class="fas fa-save"></i> Save</button>
            </div>
        </form>
    </div>
</div>

<script src="<?= BASE_URL ?>assets/js/main.js"></script>
<script>
// Dynamic position loader
function loadPositions(electionId) {
    const posSelect = document.getElementById('create_position');
    posSelect.innerHTML = '<option value="">Loading...</option>';
    if (!electionId) { posSelect.innerHTML = '<option value="">— Select Election first —</option>'; return; }
    fetch('get_positions.php?election_id=' + electionId)
        .then(r => r.json())
        .then(data => {
            posSelect.innerHTML = '<option value="">— Select Position —</option>';
            data.forEach(p => {
                posSelect.innerHTML += `<option value="${p.position_id}">${p.position_name}</option>`;
            });
        });
}
</script>
</body>
</html>
