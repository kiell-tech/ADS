<?php
// admin/get_positions.php — AJAX endpoint: returns positions JSON
session_start();
define('BASE_URL', '/bulsu_voting/');
require_once __DIR__ . '/../includes/auth_admin.php';
require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json');
$election_id = (int)($_GET['election_id'] ?? 0);
if (!$election_id) { echo '[]'; exit; }

$db   = getDB();
$stmt = $db->prepare("SELECT position_id, position_name FROM positions WHERE election_id=? ORDER BY display_order");
$stmt->execute([$election_id]);
echo json_encode($stmt->fetchAll());
