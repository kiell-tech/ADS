<?php
// ============================================================
// admin/elections.php — Elections CRUD
// ============================================================
session_start();
define('BASE_URL', '/bulsu_voting/');
require_once __DIR__ . '/../includes/auth_admin.php';
require_once __DIR__ . '/../config/db.php';
define('PAGE_TITLE', 'Manage Elections');

$db    = getDB();
$error = $success = '';

// ── POSITIONS template (fixed for CICT) ──
$default_positions = [
    ['CICT LSC President',          1],
    ['CICT LSC Vice President',     2],
    ['Secretary',                   3],
    ['Treasurer',                   4],
    ['Public Relations Officer',    5],
    ['Internal Auditor',            6],
];

// ── Handle POST actions ──
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // CREATE Election
    if ($action === 'create') {
        $name  = trim($_POST['election_name'] ?? '');
        $start = $_POST['start_date'] ?? '';
        $end   = $_POST['end_date']   ?? '';
        $status= $_POST['status']     ?? 'pending';

        if (empty($name) || empty($start) || empty($end)) {
            $error = 'All fields are required.';
        } elseif ($start >= $end) {
            $error = 'End date must be after start date.';
        } else {
            try {
                $db->beginTransaction();
                $stmt = $db->prepare(
                    "INSERT INTO elections (election_name, start_date, end_date, status, created_by)
                     VALUES (?, ?, ?, ?, ?)"
                );
                $stmt->execute([$name, $start, $end, $status, $_SESSION['admin_id']]);
                $eid = $db->lastInsertId();

                // Auto-create the 6 default positions
                $pos_stmt = $db->prepare(
                    "INSERT INTO positions (election_id, position_name, max_candidates, display_order)
                     VALUES (?, ?, 4, ?)"
                );
                foreach ($default_positions as $pos) {
                    $pos_stmt->execute([$eid, $pos[0], $pos[1]]);
                }
                $db->commit();
                $success = 'Election created successfully with default positions!';
            } catch (PDOException $e) {
                $db->rollBack();
                $error = 'Failed to create election: ' . $e->getMessage();
            }
        }
    }

    // UPDATE Election
    if ($action === 'update') {
        $id    = (int)($_POST['election_id'] ?? 0);
        $name  = trim($_POST['election_name'] ?? '');
        $start = $_POST['start_date'] ?? '';
        $end   = $_POST['end_date']   ?? '';
        $status= $_POST['status']     ?? 'pending';

        if ($start >= $end) { $error = 'End date must be after start date.'; }
        else {
            $stmt = $db->prepare(
                "UPDATE elections SET election_name=?, start_date=?, end_date=?, status=? WHERE election_id=?"
            );
            $stmt->execute([$name, $start, $end, $status, $id]);
            $success = 'Election updated successfully.';
        }
    }

    // DELETE Election
    if ($action === 'delete') {
        $id = (int)($_POST['election_id'] ?? 0);
        // Check if there are any votes
        $vcount = $db->prepare("SELECT COUNT(*) FROM votes WHERE election_id=?");
        $vcount->execute([$id]);
        if ($vcount->fetchColumn() > 0) {
            $error = 'Cannot delete election with existing votes.';
        } else {
            $db->prepare("DELETE FROM elections WHERE election_id=?")->execute([$id]);
            $success = 'Election deleted successfully.';
        }
    }
}

// ── Fetch all elections ──
$elections = $db->query(
    "SELECT e.*, a.full_name AS created_by_name,
     (SELECT COUNT(*) FROM votes v WHERE v.election_id=e.election_id) AS vote_count
     FROM elections e
     LEFT JOIN admins a ON a.admin_id = e.created_by
     ORDER BY e.election_id DESC"
)->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title><?= PAGE_TITLE ?> | BulSU CICT</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<nav class="navbar">
    <div class="navbar-brand">
        <img src="<?= BASE_URL ?>assets/images/logo_placeholder.png" alt="BulSU" onerror="this.style.display='none'">
        <div class="brand-text">
            <div class="brand-title">BulSU CICT Voting</div>
            <div class="brand-sub">Admin Panel</div>
        </div>
    </div>
    <ul class="navbar-nav">
        <li><span style="color:var(--gold-light);font-size:.85rem;"><i class="fas fa-circle-user"></i> <?= htmlspecialchars($_SESSION['admin_name']) ?></span></li>
        <li><a href="<?= BASE_URL ?>logout.php" class="btn-logout"><i class="fas fa-right-from-bracket"></i> Logout</a></li>
    </ul>
</nav>

<div class="layout">
    <aside class="sidebar">
        <div class="sidebar-section-label">Main</div>
        <ul class="sidebar-nav">
            <li><a href="dashboard.php"><i class="fas fa-gauge"></i> Dashboard</a></li>
            <li><a href="elections.php" class="active"><i class="fas fa-calendar-check"></i> Elections</a></li>
            <li><a href="positions.php"><i class="fas fa-list-check"></i> Positions</a></li>
            <li><a href="candidates.php"><i class="fas fa-users"></i> Candidates</a></li>
        </ul>
        <div class="sidebar-section-label">Management</div>
        <ul class="sidebar-nav">
            <li><a href="voters.php"><i class="fas fa-user-check"></i> Voters</a></li>
            <li><a href="results.php"><i class="fas fa-chart-bar"></i> Results</a></li>
            <li><a href="backup.php"><i class="fas fa-database"></i> Backup</a></li>
        </ul>
    </aside>

    <main class="main-content">
        <div class="page-header">
            <div>
                <div class="breadcrumb"><i class="fas fa-home"></i> Admin <span>/ Elections</span></div>
                <h1>Elections</h1>
                <p>Create and manage CICT student elections</p>
            </div>
            <button class="btn btn-primary" data-modal-open="modal-create">
                <i class="fas fa-plus"></i> New Election
            </button>
        </div>

        <?php if ($error):   ?><div class="alert alert-error"><i class="fas fa-circle-exclamation"></i><?= htmlspecialchars($error) ?></div><?php endif; ?>
        <?php if ($success): ?><div class="alert alert-success"><i class="fas fa-circle-check"></i><?= htmlspecialchars($success) ?></div><?php endif; ?>

        <div class="card">
            <div class="card-header"><h3><i class="fas fa-calendar-check"></i> All Elections</h3></div>
            <div class="table-wrap">
                <?php if (empty($elections)): ?>
                    <div class="empty-state"><i class="fas fa-calendar-xmark"></i><p>No elections created yet.</p></div>
                <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Election Name</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                            <th>Status</th>
                            <th>Votes</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($elections as $e): ?>
                        <tr>
                            <td><?= $e['election_id'] ?></td>
                            <td><strong><?= htmlspecialchars($e['election_name']) ?></strong></td>
                            <td><?= date('M d, Y g:i A', strtotime($e['start_date'])) ?></td>
                            <td><?= date('M d, Y g:i A', strtotime($e['end_date'])) ?></td>
                            <td><span class="badge badge-<?= $e['status'] ?>"><?= ucfirst($e['status']) ?></span></td>
                            <td><?= $e['vote_count'] ?></td>
                            <td class="td-actions">
                                <button class="btn btn-outline btn-sm"
                                    data-modal-open="modal-edit"
                                    data-edit='<?= json_encode([
                                        "election_id"   => $e["election_id"],
                                        "election_name" => $e["election_name"],
                                        "start_date"    => date("Y-m-d\TH:i", strtotime($e["start_date"])),
                                        "end_date"      => date("Y-m-d\TH:i", strtotime($e["end_date"])),
                                        "status"        => $e["status"]
                                    ]) ?>'>
                                    <i class="fas fa-pen"></i> Edit
                                </button>
                                <?php if ($e['vote_count'] == 0): ?>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="election_id" value="<?= $e['election_id'] ?>">
                                    <button type="submit" class="btn btn-danger btn-sm confirm-delete"
                                        data-confirm="Delete this election and all its positions/candidates?">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>
        </div>
    </main>
</div>

<!-- CREATE Modal -->
<div class="modal-overlay" id="modal-create">
    <div class="modal">
        <div class="modal-header">
            <h3><i class="fas fa-plus-circle"></i> Create New Election</h3>
            <button class="modal-close">&times;</button>
        </div>
        <form method="POST">
            <input type="hidden" name="action" value="create">
            <div class="modal-body">
                <div class="form-group">
                    <label>Election Name</label>
                    <input type="text" name="election_name" class="form-control" placeholder="e.g. CICT LSC Election 2025" required>
                </div>
                <div class="form-group">
                    <label>Start Date & Time</label>
                    <input type="datetime-local" name="start_date" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>End Date & Time</label>
                    <input type="datetime-local" name="end_date" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Status</label>
                    <select name="status" class="form-control">
                        <option value="pending">Pending</option>
                        <option value="active">Active</option>
                        <option value="closed">Closed</option>
                    </select>
                </div>
                <div class="alert alert-info">
                    <i class="fas fa-circle-info"></i>
                    <span>6 default CICT positions will be created automatically.</span>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" data-modal-close>Cancel</button>
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Create Election</button>
            </div>
        </form>
    </div>
</div>

<!-- EDIT Modal -->
<div class="modal-overlay" id="modal-edit">
    <div class="modal">
        <div class="modal-header">
            <h3><i class="fas fa-pen"></i> Edit Election</h3>
            <button class="modal-close">&times;</button>
        </div>
        <form method="POST">
            <input type="hidden" name="action" value="update">
            <input type="hidden" name="election_id">
            <div class="modal-body">
                <div class="form-group">
                    <label>Election Name</label>
                    <input type="text" name="election_name" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Start Date & Time</label>
                    <input type="datetime-local" name="start_date" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>End Date & Time</label>
                    <input type="datetime-local" name="end_date" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Status</label>
                    <select name="status" class="form-control">
                        <option value="pending">Pending</option>
                        <option value="active">Active</option>
                        <option value="closed">Closed</option>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" data-modal-close>Cancel</button>
                <button type="submit" class="btn btn-gold"><i class="fas fa-save"></i> Save Changes</button>
            </div>
        </form>
    </div>
</div>

<script src="<?= BASE_URL ?>assets/js/main.js"></script>
</body>
</html>
